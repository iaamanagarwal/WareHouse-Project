import { useState, useMemo } from 'react'
import { motion } from 'framer-motion'
import { Bot, ClipboardList, Package } from 'lucide-react'
import useWarehouseStore from '../store/useWarehouseStore'
import PageContainer from '../components/layout/PageContainer'
import SearchInput from '../components/common/SearchInput'
import Pagination from '../components/common/Pagination'
import RobotCard from '../components/robots/RobotCard'
import RobotStatusBarChart from '../components/robots/RobotStatusBarChart'
import WarehouseMap from '../components/warehouse/WarehouseMap'
import Warehouse3DView from '../components/warehouse/Warehouse3DView'

/**
 * Robots overview page with search, pagination, and status chart
 */
function RobotsPage() {
  const { robots, getRobotStatusCounts } = useWarehouseStore()
  const [searchTerm, setSearchTerm] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const [selectedStatus, setSelectedStatus] = useState('All')
  const [selectedRobot, setSelectedRobot] = useState(null)
  const robotsPerPage = 8

  // Filter robots based on search and status
  const filteredRobots = useMemo(() => {
    return robots.filter(robot => {
      const matchesSearch = 
        robot.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        robot.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        robot.location.toLowerCase().includes(searchTerm.toLowerCase())
      
      const matchesStatus = selectedStatus === 'All' || robot.status === selectedStatus
      
      return matchesSearch && matchesStatus
    })
  }, [robots, searchTerm, selectedStatus])

  // Pagination calculations
  const totalPages = Math.ceil(filteredRobots.length / robotsPerPage)
  const startIndex = (currentPage - 1) * robotsPerPage
  const paginatedRobots = filteredRobots.slice(startIndex, startIndex + robotsPerPage)

  // Chart data
  const chartData = getRobotStatusCounts()

  // Reset pagination when filters change
  useState(() => {
    setCurrentPage(1)
  }, [searchTerm, selectedStatus])

  const handleRobotClick = (robot) => {
    setSelectedRobot(robot.id === selectedRobot ? null : robot.id)
    console.log('Robot clicked:', robot)
    // Could open a modal with robot details or navigate to robot detail page
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20, scale: 0.95 },
    visible: { 
      opacity: 1, 
      y: 0, 
      scale: 1,
      transition: {
        duration: 0.4,
        ease: "easeOut"
      }
    }
  }

  return (
    <PageContainer 
      title="Robot Overview"
      description="Monitor and manage your warehouse robot fleet in real-time"
    >
      <div className="space-y-6">
        {/* Filters and Search */}
        <div className="flex flex-col lg:flex-row gap-6">
          <div className="flex-1">
            <SearchInput
              value={searchTerm}
              onChange={setSearchTerm}
              placeholder="Search robots by ID, name, or location..."
              className="w-full"
            />
          </div>
          
          <div className="flex gap-3 flex-wrap">
            {['All', 'Idle', 'Busy', 'Charging'].map((status) => (
              <motion.button
                key={status}
                onClick={() => setSelectedStatus(status)}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className={`px-6 py-3 rounded-xl text-sm font-medium transition-all duration-200 backdrop-blur-sm border shadow-sm hover:shadow-md ${
                  selectedStatus === status
                    ? 'bg-gradient-to-r from-primary-600 to-purple-600 text-white border-primary-500/50 shadow-lg'
                    : 'bg-white/70 dark:bg-gray-800/70 text-gray-700 dark:text-gray-300 hover:bg-white/90 dark:hover:bg-gray-700/90 border-white/30 dark:border-gray-600/30'
                }`}
              >
                {status}
                {status !== 'All' && (
                  <span className="ml-2 px-2 py-1 text-xs bg-black/10 dark:bg-white/10 rounded-full">
                    {robots.filter(r => r.status.toLowerCase() === status.toLowerCase()).length}
                  </span>
                )}
              </motion.button>
            ))}
          </div>
        </div>

        {/* Stats Summary */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 dark:from-blue-500/20 dark:to-cyan-500/20 backdrop-blur-sm p-6 rounded-xl border border-blue-200/30 dark:border-blue-700/30 shadow-sm hover:shadow-md transition-all duration-300 group"
          >
            <div className="flex items-center justify-between">
              <div>
                <div className="text-3xl font-bold text-gray-900 dark:text-gray-100 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                  {robots.length}
                </div>
                <div className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Robots</div>
              </div>
              <div className="p-3 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl shadow-md">
                <Bot className="h-6 w-6 text-white" />
              </div>
            </div>
          </motion.div>
          
          {chartData.map((item, index) => {
            const gradients = {
              'Idle': 'from-gray-500/10 to-slate-500/10 dark:from-gray-500/20 dark:to-slate-500/20',
              'Busy': 'from-amber-500/10 to-orange-500/10 dark:from-amber-500/20 dark:to-orange-500/20',
              'Charging': 'from-green-500/10 to-emerald-500/10 dark:from-green-500/20 dark:to-emerald-500/20'
            }
            const iconGradients = {
              'Idle': 'from-gray-500 to-slate-500',
              'Busy': 'from-amber-500 to-orange-500',
              'Charging': 'from-green-500 to-emerald-500'
            }
            const icons = {
              'Idle': Bot,
              'Busy': ClipboardList,
              'Charging': Package
            }
            const Icon = icons[item.status] || Bot

            return (
              <motion.div 
                key={item.status} 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 + index * 0.1 }}
                className={`bg-gradient-to-br ${gradients[item.status] || gradients['Idle']} backdrop-blur-sm p-6 rounded-xl border border-white/20 dark:border-gray-700/20 shadow-sm hover:shadow-md transition-all duration-300 group cursor-pointer`}
                whileHover={{ scale: 1.02 }}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-3xl font-bold text-gray-900 dark:text-gray-100 group-hover:scale-110 transition-transform">
                      {item.count}
                    </div>
                    <div className="text-sm font-medium text-gray-600 dark:text-gray-400 capitalize">
                      {item.status}
                    </div>
                  </div>
                  <div className={`p-3 bg-gradient-to-br ${iconGradients[item.status] || iconGradients['Idle']} rounded-xl shadow-md group-hover:shadow-lg transition-shadow`}>
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                </div>
              </motion.div>
            )
          })}
        </div>

        {/* Chart */}
        <RobotStatusBarChart data={chartData} />

        {/* Warehouse Visualizations */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          <WarehouseMap 
            selectedRobot={selectedRobot} 
            onRobotClick={handleRobotClick}
          />
          <Warehouse3DView 
            robots={robots} 
            selectedRobot={selectedRobot}
          />
        </div>

        {/* Results count */}
        <div className="flex items-center justify-between">
          <p className="text-sm text-gray-700 dark:text-gray-300">
            Showing {paginatedRobots.length} of {filteredRobots.length} robots
            {searchTerm && ` matching "${searchTerm}"`}
            {selectedStatus !== 'All' && ` with status "${selectedStatus}"`}
          </p>
        </div>

        {/* Robot Grid */}
        <motion.div
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-6"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {paginatedRobots.map((robot, index) => (
            <motion.div
              key={robot.id}
              variants={itemVariants}
              transition={{ delay: index * 0.1 }}
            >
              <RobotCard
                robot={robot}
                onClick={() => handleRobotClick(robot)}
              />
            </motion.div>
          ))}
        </motion.div>

        {/* Empty state */}
        {filteredRobots.length === 0 && (
          <div className="text-center py-12">
            <div className="text-gray-400 dark:text-gray-600 text-4xl mb-4">🤖</div>
            <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
              No robots found
            </h3>
            <p className="text-gray-500 dark:text-gray-400">
              {searchTerm || selectedStatus !== 'All'
                ? 'Try adjusting your search or filter criteria.'
                : 'No robots are currently registered in the system.'}
            </p>
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center">
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
            />
          </div>
        )}
      </div>
    </PageContainer>
  )
}

export default RobotsPage