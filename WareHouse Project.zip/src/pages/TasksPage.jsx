import { useState } from 'react'
import { motion } from 'framer-motion'
import { Plus } from 'lucide-react'
import useWarehouseStore from '../store/useWarehouseStore'
import PageContainer from '../components/layout/PageContainer'
import TaskList from '../components/tasks/TaskList'
import TaskFormEnhanced from '../components/tasks/TaskFormEnhanced'
import Modal from '../components/common/Modal'

/**
 * Tasks management page with active/completed tabs and task creation
 */
function TasksPage() {
  const { getActiveTasks, getCompletedTasks } = useWarehouseStore()
  const [activeTab, setActiveTab] = useState('active')
  const [showCreateModal, setShowCreateModal] = useState(false)

  const activeTasks = getActiveTasks()
  const completedTasks = getCompletedTasks()

  const handleTaskCreated = () => {
    setShowCreateModal(false)
    // Could show a success message here
  }

  const tabs = [
    { id: 'active', label: 'Active Tasks', count: activeTasks.length },
    { id: 'completed', label: 'Completed Tasks', count: completedTasks.length }
  ]

  const pageActions = (
    <button
      onClick={() => setShowCreateModal(true)}
      className="btn-primary inline-flex items-center"
    >
      <Plus className="h-4 w-4 mr-2" />
      Create Task
    </button>
  )

  return (
    <PageContainer title="Task Management" actions={pageActions}>
      <div className="space-y-6">
        {/* Summary Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-warehouse-card dark:bg-warehouse-card-dark p-4 rounded-lg border border-warehouse-border dark:border-warehouse-border-dark">
            <div className="text-2xl font-bold text-gray-900 dark:text-gray-100">
              {activeTasks.filter(t => t.status === 'Pending').length}
            </div>
            <div className="text-sm text-gray-500 dark:text-gray-400">Pending Tasks</div>
          </div>
          
          <div className="bg-warehouse-card dark:bg-warehouse-card-dark p-4 rounded-lg border border-warehouse-border dark:border-warehouse-border-dark">
            <div className="text-2xl font-bold text-gray-900 dark:text-gray-100">
              {activeTasks.filter(t => t.status === 'In-progress').length}
            </div>
            <div className="text-sm text-gray-500 dark:text-gray-400">In Progress</div>
          </div>
          
          <div className="bg-warehouse-card dark:bg-warehouse-card-dark p-4 rounded-lg border border-warehouse-border dark:border-warehouse-border-dark">
            <div className="text-2xl font-bold text-gray-900 dark:text-gray-100">
              {completedTasks.length}
            </div>
            <div className="text-sm text-gray-500 dark:text-gray-400">Completed</div>
          </div>
        </div>

        {/* Tabs */}
        <div className="border-b border-warehouse-border dark:border-warehouse-border-dark">
          <nav className="-mb-px flex space-x-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-2 px-1 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? 'border-primary-500 text-primary-600 dark:text-primary-400'
                    : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300 hover:border-gray-300'
                }`}
              >
                {tab.label}
                <span className="ml-2 px-2 py-0.5 rounded-full text-xs bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400">
                  {tab.count}
                </span>
              </button>
            ))}
          </nav>
        </div>

        {/* Task Lists */}
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          {activeTab === 'active' ? (
            <TaskList
              tasks={activeTasks}
              title="Active Tasks"
              showActions={true}
            />
          ) : (
            <TaskList
              tasks={completedTasks}
              title="Completed Tasks"
              showActions={false}
            />
          )}
        </motion.div>

        {/* Create Task Modal */}
        <Modal
          isOpen={showCreateModal}
          onClose={() => setShowCreateModal(false)}
          title="Create New Task"
          size="lg"
        >
          <TaskFormEnhanced onTaskCreated={handleTaskCreated} />
        </Modal>
      </div>
    </PageContainer>
  )
}

export default TasksPage