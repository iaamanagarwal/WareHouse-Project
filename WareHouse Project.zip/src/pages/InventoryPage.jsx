import { motion } from 'framer-motion'
import { AlertTriangle, Package, TrendingDown, BarChart3 } from 'lucide-react'
import useWarehouseStore from '../store/useWarehouseStore'
import PageContainer from '../components/layout/PageContainer'
import InventoryTable from '../components/inventory/InventoryTable'
import InventoryChart from '../components/inventory/InventoryChart'

/**
 * Inventory management page with table, charts, and low stock alerts
 */
function InventoryPage() {
  const { inventory, getLowStockItems, getInventoryByCategory } = useWarehouseStore()

  const lowStockItems = getLowStockItems()
  const categoryData = getInventoryByCategory()
  const totalValue = inventory.reduce((sum, item) => sum + (item.quantity * item.unitCost), 0)

  const handleItemClick = (item) => {
    console.log('Item clicked:', item)
    // Could open a modal with item details or navigate to item detail page
  }

  return (
    <PageContainer title="Inventory Management">
      <div className="space-y-6">
        {/* Summary Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-warehouse-card dark:bg-warehouse-card-dark p-4 rounded-lg border border-warehouse-border dark:border-warehouse-border-dark">
            <div className="flex items-center">
              <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg mr-3">
                <Package className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                  {inventory.length}
                </div>
                <div className="text-sm text-gray-500 dark:text-gray-400">Total Items</div>
              </div>
            </div>
          </div>
          
          <div className="bg-warehouse-card dark:bg-warehouse-card-dark p-4 rounded-lg border border-warehouse-border dark:border-warehouse-border-dark">
            <div className="flex items-center">
              <div className="p-2 bg-red-100 dark:bg-red-900 rounded-lg mr-3">
                <AlertTriangle className="h-6 w-6 text-red-600 dark:text-red-400" />
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                  {lowStockItems.length}
                </div>
                <div className="text-sm text-gray-500 dark:text-gray-400">Low Stock</div>
              </div>
            </div>
          </div>
          
          <div className="bg-warehouse-card dark:bg-warehouse-card-dark p-4 rounded-lg border border-warehouse-border dark:border-warehouse-border-dark">
            <div className="flex items-center">
              <div className="p-2 bg-green-100 dark:bg-green-900 rounded-lg mr-3">
                <BarChart3 className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                  {inventory.reduce((sum, item) => sum + item.quantity, 0).toLocaleString()}
                </div>
                <div className="text-sm text-gray-500 dark:text-gray-400">Total Units</div>
              </div>
            </div>
          </div>
          
          <div className="bg-warehouse-card dark:bg-warehouse-card-dark p-4 rounded-lg border border-warehouse-border dark:border-warehouse-border-dark">
            <div className="flex items-center">
              <div className="p-2 bg-purple-100 dark:bg-purple-900 rounded-lg mr-3">
                <TrendingDown className="h-6 w-6 text-purple-600 dark:text-purple-400" />
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                  ${totalValue.toLocaleString()}
                </div>
                <div className="text-sm text-gray-500 dark:text-gray-400">Total Value</div>
              </div>
            </div>
          </div>
        </div>

        {/* Low Stock Alert */}
        {lowStockItems.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4"
          >
            <div className="flex items-center">
              <AlertTriangle className="h-5 w-5 text-red-600 dark:text-red-400 mr-3" />
              <div className="flex-1">
                <h4 className="text-sm font-medium text-red-800 dark:text-red-300">
                  Low Stock Alert
                </h4>
                <p className="text-sm text-red-700 dark:text-red-400 mt-1">
                  {lowStockItems.length} item{lowStockItems.length !== 1 ? 's' : ''} {lowStockItems.length === 1 ? 'is' : 'are'} running low on stock and need{lowStockItems.length === 1 ? 's' : ''} attention.
                </p>
                <div className="mt-2 flex flex-wrap gap-1">
                  {lowStockItems.slice(0, 5).map(item => (
                    <span
                      key={item.id}
                      className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-200"
                    >
                      {item.name} ({item.quantity})
                    </span>
                  ))}
                  {lowStockItems.length > 5 && (
                    <span className="text-xs text-red-600 dark:text-red-400">
                      +{lowStockItems.length - 5} more
                    </span>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <InventoryChart data={categoryData} type="pie" />
          <InventoryChart data={categoryData} type="bar" />
        </div>

        {/* Inventory Table */}
        <InventoryTable items={inventory} onItemClick={handleItemClick} />
      </div>
    </PageContainer>
  )
}

export default InventoryPage