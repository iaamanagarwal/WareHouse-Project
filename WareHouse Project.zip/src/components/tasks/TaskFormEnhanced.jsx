import { useState } from 'react'
import { useForm, Controller } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import useWarehouseStore from '../../store/useWarehouseStore'
import Card from '../common/Card'
import StatusChip from '../common/StatusChip'

// Validation schema
const taskSchema = yup.object().shape({
  itemId: yup
    .string()
    .required('Please select an item'),
  source: yup
    .string()
    .required('Source location is required'),
  destination: yup
    .string()
    .required('Destination location is required')
    .test('different-from-source', 'Destination must be different from source', function(value) {
      return value !== this.parent.source
    }),
  robotId: yup.string(),
  priority: yup
    .string()
    .oneOf(['Low', 'Medium', 'High'], 'Priority must be Low, Medium, or High')
    .required('Priority is required')
})

/**
 * Enhanced form for creating new tasks with validation
 * @param {Object} props
 * @param {Function} props.onTaskCreated - Callback after task creation
 */
function TaskFormEnhanced({ onTaskCreated }) {
  const { inventory, addTask, getAvailableRobots } = useWarehouseStore()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitError, setSubmitError] = useState('')
  const [submitSuccess, setSubmitSuccess] = useState(false)

  const {
    control,
    handleSubmit,
    reset,
    watch,
    formState: { errors, isValid, isDirty }
  } = useForm({
    resolver: yupResolver(taskSchema),
    defaultValues: {
      itemId: '',
      source: '',
      destination: '',
      robotId: '',
      priority: 'Medium'
    },
    mode: 'onChange'
  })

  const availableRobots = getAvailableRobots()
  const selectedItemId = watch('itemId')
  const selectedItem = inventory.find(item => item.id === selectedItemId)
  
  const warehouseLocations = [
    'Zone A1', 'Zone A2', 'Zone A3',
    'Zone B1', 'Zone B2', 'Zone B3', 
    'Zone C1', 'Zone C2', 'Zone C3',
    'Zone D1', 'Zone D2', 'Zone D3',
    'Receiving Dock', 'Shipping Dock',
    'Production Line 1', 'Production Line 2', 'Production Line 3',
    'Assembly Area', 'QC Lab', 'Maintenance Area'
  ]

  const onSubmit = async (data) => {
    setIsSubmitting(true)
    setSubmitError('')
    setSubmitSuccess(false)

    try {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1000))

      const selectedItem = inventory.find(item => item.id === data.itemId)
      
      if (!selectedItem) {
        throw new Error('Selected item not found')
      }

      // Check if item has sufficient quantity
      if (selectedItem.quantity <= 0) {
        throw new Error('Selected item is out of stock')
      }

      const newTask = {
        description: `Move ${selectedItem.name} from ${data.source} to ${data.destination}`,
        robotId: data.robotId || null,
        itemId: data.itemId,
        source: data.source,
        destination: data.destination,
        priority: data.priority
      }

      addTask(newTask)
      
      // Reset form
      reset()
      setSubmitSuccess(true)

      if (onTaskCreated) {
        onTaskCreated()
      }

      // Clear success message after 3 seconds
      setTimeout(() => setSubmitSuccess(false), 3000)
    } catch (error) {
      setSubmitError(error.message || 'Failed to create task. Please try again.')
    } finally {
      setIsSubmitting(false)
    }
  }

  const FormField = ({ label, error, children, required = false }) => (
    <div>
      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      {children}
      {error && (
        <p className="text-red-600 dark:text-red-400 text-sm mt-1 flex items-center">
          <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
          </svg>
          {error.message}
        </p>
      )}
    </div>
  )

  return (
    <Card>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4" noValidate>
        <div>
          <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
            Create New Task
          </h3>
        </div>

        {/* Success Message */}
        {submitSuccess && (
          <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-700 text-green-700 dark:text-green-300 px-4 py-3 rounded-md flex items-center">
            <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
            Task created successfully!
          </div>
        )}

        {/* Error Message */}
        {submitError && (
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700 text-red-700 dark:text-red-300 px-4 py-3 rounded-md flex items-center">
            <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
            </svg>
            {submitError}
          </div>
        )}

        {/* Item Selection */}
        <FormField label="Select Item" error={errors.itemId} required>
          <Controller
            name="itemId"
            control={control}
            render={({ field }) => (
              <select
                {...field}
                className={`w-full p-3 border rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:border-transparent transition-colors ${
                  errors.itemId 
                    ? 'border-red-300 dark:border-red-600 focus:ring-red-500' 
                    : 'border-gray-300 dark:border-gray-600 focus:ring-blue-500'
                }`}
                aria-invalid={errors.itemId ? 'true' : 'false'}
                aria-describedby={errors.itemId ? 'itemId-error' : undefined}
              >
                <option value="">Choose an item...</option>
                {inventory.map(item => (
                  <option key={item.id} value={item.id} disabled={item.quantity <= 0}>
                    {item.name} (Qty: {item.quantity}) - {item.location}
                    {item.quantity <= 0 && ' [OUT OF STOCK]'}
                  </option>
                ))}
              </select>
            )}
          />
        </FormField>

        {/* Selected Item Preview */}
        {selectedItem && (
          <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-700 p-3 rounded-lg">
            <p className="text-sm text-blue-700 dark:text-blue-300">
              <strong>Selected:</strong> {selectedItem.name} | 
              <strong> Category:</strong> {selectedItem.category} | 
              <strong> Current Location:</strong> {selectedItem.location}
              {selectedItem.quantity <= selectedItem.minStock && (
                <span className="text-amber-600 dark:text-amber-400 ml-2">⚠️ Low Stock</span>
              )}
            </p>
          </div>
        )}

        {/* Source Location */}
        <FormField label="Source Location" error={errors.source} required>
          <Controller
            name="source"
            control={control}
            render={({ field }) => (
              <select
                {...field}
                className={`w-full p-3 border rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:border-transparent transition-colors ${
                  errors.source 
                    ? 'border-red-300 dark:border-red-600 focus:ring-red-500' 
                    : 'border-gray-300 dark:border-gray-600 focus:ring-blue-500'
                }`}
                aria-invalid={errors.source ? 'true' : 'false'}
              >
                <option value="">Select source location...</option>
                {warehouseLocations.map(location => (
                  <option key={location} value={location}>
                    {location}
                  </option>
                ))}
              </select>
            )}
          />
        </FormField>

        {/* Destination Location */}
        <FormField label="Destination Location" error={errors.destination} required>
          <Controller
            name="destination"
            control={control}
            render={({ field }) => (
              <select
                {...field}
                className={`w-full p-3 border rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:border-transparent transition-colors ${
                  errors.destination 
                    ? 'border-red-300 dark:border-red-600 focus:ring-red-500' 
                    : 'border-gray-300 dark:border-gray-600 focus:ring-blue-500'
                }`}
                aria-invalid={errors.destination ? 'true' : 'false'}
              >
                <option value="">Select destination location...</option>
                {warehouseLocations.map(location => (
                  <option key={location} value={location}>
                    {location}
                  </option>
                ))}
              </select>
            )}
          />
        </FormField>

        {/* Priority */}
        <FormField label="Priority" error={errors.priority}>
          <Controller
            name="priority"
            control={control}
            render={({ field }) => (
              <div className="flex gap-3">
                {['Low', 'Medium', 'High'].map((priority) => (
                  <label key={priority} className="flex items-center cursor-pointer">
                    <input
                      type="radio"
                      value={priority}
                      checked={field.value === priority}
                      onChange={() => field.onChange(priority)}
                      className="sr-only"
                    />
                    <div className={`px-4 py-2 rounded-lg border transition-colors ${
                      field.value === priority
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 border-gray-300 dark:border-gray-600 hover:border-blue-400'
                    }`}>
                      {priority}
                    </div>
                  </label>
                ))}
              </div>
            )}
          />
        </FormField>

        {/* Robot Assignment */}
        <FormField label="Assign Robot (Optional)" error={errors.robotId}>
          <Controller
            name="robotId"
            control={control}
            render={({ field }) => (
              <select
                {...field}
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
              >
                <option value="">Auto-assign when robot becomes available</option>
                {availableRobots.map(robot => (
                  <option key={robot.id} value={robot.id}>
                    {robot.name} ({robot.id}) - {robot.location} - Battery: {robot.batteryLevel}%
                  </option>
                ))}
              </select>
            )}
          />
          {availableRobots.length === 0 && (
            <p className="text-amber-600 dark:text-amber-400 text-sm mt-1 flex items-center">
              <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
              No idle robots available. Task will be queued.
            </p>
          )}
        </FormField>

        {/* Form Progress Indicator */}
        <div className="bg-gray-50 dark:bg-gray-800/50 p-3 rounded-lg">
          <div className="flex justify-between items-center text-sm">
            <span className="text-gray-600 dark:text-gray-400">Form Completion</span>
            <span className="text-gray-900 dark:text-gray-100 font-medium">
              {Object.values(errors).length === 0 && isDirty ? '✓ Ready' : 'In Progress'}
            </span>
          </div>
          <div className="mt-2 bg-gray-200 dark:bg-gray-700 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all duration-300"
              style={{ 
                width: `${Object.values(errors).length === 0 && isDirty ? 100 : (isDirty ? 60 : 0)}%` 
              }}
            />
          </div>
        </div>

        {/* Submit Button */}
        <div className="pt-4">
          <button
            type="submit"
            disabled={isSubmitting || !isValid}
            className={`w-full px-6 py-3 rounded-lg font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
              isSubmitting || !isValid
                ? 'bg-gray-300 dark:bg-gray-700 text-gray-500 dark:text-gray-400 cursor-not-allowed'
                : 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg hover:shadow-xl'
            }`}
          >
            {isSubmitting ? (
              <div className="flex items-center justify-center">
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                Creating Task...
              </div>
            ) : (
              'Create Task'
            )}
          </button>
        </div>
      </form>
    </Card>
  )
}

export default TaskFormEnhanced