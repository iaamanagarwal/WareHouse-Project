import { useState } from 'react'
import useWarehouseStore from '../../store/useWarehouseStore'
import Card from '../common/Card'
import StatusChip from '../common/StatusChip'

/**
 * Form for creating new tasks
 * @param {Object} props
 * @param {Function} props.onTaskCreated - Callback after task creation
 */
function TaskForm({ onTaskCreated }) {
  const { inventory, addTask, getAvailableRobots } = useWarehouseStore()
  const [formData, setFormData] = useState({
    itemId: '',
    source: '',
    destination: '',
    robotId: '',
    priority: 'Medium'
  })
  const [isSubmitting, setIsSubmitting] = useState(false)

  const availableRobots = getAvailableRobots()
  
  const warehouseLocations = [
    'Zone A1', 'Zone A2', 'Zone A3',
    'Zone B1', 'Zone B2', 'Zone B3', 
    'Zone C1', 'Zone C2', 'Zone C3',
    'Zone D1', 'Zone D2', 'Zone D3',
    'Receiving Dock', 'Shipping Dock',
    'Production Line 1', 'Production Line 2', 'Production Line 3',
    'Assembly Area', 'QC Lab', 'Maintenance Area'
  ]

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!formData.itemId || !formData.source || !formData.destination) {
      return
    }

    setIsSubmitting(true)

    try {
      const selectedItem = inventory.find(item => item.id === formData.itemId)
      const newTask = {
        description: `Move ${selectedItem?.name || 'Item'} from ${formData.source} to ${formData.destination}`,
        robotId: formData.robotId || null,
        itemId: formData.itemId,
        source: formData.source,
        destination: formData.destination,
        priority: formData.priority
      }

      addTask(newTask)
      
      // Reset form
      setFormData({
        itemId: '',
        source: '',
        destination: '',
        robotId: '',
        priority: 'Medium'
      })

      if (onTaskCreated) {
        onTaskCreated()
      }
    } catch (error) {
      console.error('Error creating task:', error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  return (
    <Card>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
            Create New Task
          </h3>
        </div>

        {/* Item Selection */}
        <div>
          <label htmlFor="itemId" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Select Item *
          </label>
          <select
            id="itemId"
            value={formData.itemId}
            onChange={(e) => handleChange('itemId', e.target.value)}
            className="w-full p-2 border border-warehouse-border dark:border-warehouse-border-dark rounded-md bg-warehouse-card dark:bg-warehouse-card-dark text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            required
          >
            <option value="">Choose an item...</option>
            {inventory.map(item => (
              <option key={item.id} value={item.id}>
                {item.name} (Qty: {item.quantity}) - {item.location}
              </option>
            ))}
          </select>
        </div>

        {/* Source Location */}
        <div>
          <label htmlFor="source" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Source Location *
          </label>
          <select
            id="source"
            value={formData.source}
            onChange={(e) => handleChange('source', e.target.value)}
            className="w-full p-2 border border-warehouse-border dark:border-warehouse-border-dark rounded-md bg-warehouse-card dark:bg-warehouse-card-dark text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            required
          >
            <option value="">Select source location...</option>
            {warehouseLocations.map(location => (
              <option key={location} value={location}>
                {location}
              </option>
            ))}
          </select>
        </div>

        {/* Destination Location */}
        <div>
          <label htmlFor="destination" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Destination Location *
          </label>
          <select
            id="destination"
            value={formData.destination}
            onChange={(e) => handleChange('destination', e.target.value)}
            className="w-full p-2 border border-warehouse-border dark:border-warehouse-border-dark rounded-md bg-warehouse-card dark:bg-warehouse-card-dark text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            required
          >
            <option value="">Select destination location...</option>
            {warehouseLocations.map(location => (
              <option key={location} value={location}>
                {location}
              </option>
            ))}
          </select>
        </div>

        {/* Priority */}
        <div>
          <label htmlFor="priority" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Priority
          </label>
          <select
            id="priority"
            value={formData.priority}
            onChange={(e) => handleChange('priority', e.target.value)}
            className="w-full p-2 border border-warehouse-border dark:border-warehouse-border-dark rounded-md bg-warehouse-card dark:bg-warehouse-card-dark text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
          >
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
          </select>
        </div>

        {/* Robot Assignment (Optional) */}
        <div>
          <label htmlFor="robotId" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Assign Robot (Optional)
          </label>
          <select
            id="robotId"
            value={formData.robotId}
            onChange={(e) => handleChange('robotId', e.target.value)}
            className="w-full p-2 border border-warehouse-border dark:border-warehouse-border-dark rounded-md bg-warehouse-card dark:bg-warehouse-card-dark text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
          >
            <option value="">No robot assigned (will be pending)</option>
            {availableRobots.map(robot => (
              <option key={robot.id} value={robot.id}>
                {robot.name} ({robot.id}) - {robot.location}
              </option>
            ))}
          </select>
          {availableRobots.length === 0 && (
            <p className="text-sm text-amber-600 dark:text-amber-400 mt-1">
              No idle robots available. Task will be created as pending.
            </p>
          )}
        </div>

        {/* Submit Button */}
        <div className="pt-4">
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? 'Creating Task...' : 'Create Task'}
          </button>
        </div>
      </form>
    </Card>
  )
}

export default TaskForm