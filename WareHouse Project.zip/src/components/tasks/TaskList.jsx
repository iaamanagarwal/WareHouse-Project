import { useState, useMemo } from 'react'
import { motion } from 'framer-motion'
import { Clock, User, MapPin, ArrowRight, CheckCircle, Play } from 'lucide-react'
import useWarehouseStore from '../../store/useWarehouseStore'
import Card from '../common/Card'
import StatusChip from '../common/StatusChip'
import SearchInput from '../common/SearchInput'
import Pagination from '../common/Pagination'

/**
 * List component for displaying and managing tasks
 * @param {Object} props
 * @param {Array} props.tasks - Array of tasks to display
 * @param {string} props.title - Section title
 * @param {boolean} props.showActions - Whether to show action buttons
 */
function TaskList({ tasks, title, showActions = false }) {
  const { robots, updateTaskStatus, assignRobotToTask, getAvailableRobots } = useWarehouseStore()
  const [searchTerm, setSearchTerm] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const tasksPerPage = 5

  // Filter tasks based on search
  const filteredTasks = useMemo(() => {
    return tasks.filter(task => {
      const robot = robots.find(r => r.id === task.robotId)
      const robotName = robot ? robot.name : 'Unassigned'
      
      return (
        task.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.status.toLowerCase().includes(searchTerm.toLowerCase()) ||
        robotName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.source.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.destination.toLowerCase().includes(searchTerm.toLowerCase())
      )
    })
  }, [tasks, searchTerm, robots])

  // Pagination
  const totalPages = Math.ceil(filteredTasks.length / tasksPerPage)
  const startIndex = (currentPage - 1) * tasksPerPage
  const paginatedTasks = filteredTasks.slice(startIndex, startIndex + tasksPerPage)

  const availableRobots = getAvailableRobots()

  const handleCompleteTask = (taskId, robotId) => {
    updateTaskStatus(taskId, 'Completed', robotId)
  }

  const handleAssignRobot = (taskId, robotId) => {
    assignRobotToTask(taskId, robotId)
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const listVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }

  const itemVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: { opacity: 1, x: 0 }
  }

  return (
    <Card>
      <div className="space-y-4">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
              {title}
            </h3>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {filteredTasks.length} task{filteredTasks.length !== 1 ? 's' : ''}
            </p>
          </div>

          {tasks.length > 0 && (
            <div className="mt-4 sm:mt-0 w-full sm:w-auto">
              <SearchInput
                value={searchTerm}
                onChange={setSearchTerm}
                placeholder="Search tasks..."
                className="w-full sm:w-64"
              />
            </div>
          )}
        </div>

        {/* Task List */}
        {paginatedTasks.length > 0 ? (
          <motion.div
            className="space-y-3"
            variants={listVariants}
            initial="hidden"
            animate="visible"
          >
            {paginatedTasks.map((task) => {
              const robot = robots.find(r => r.id === task.robotId)
              
              return (
                <motion.div
                  key={task.id}
                  variants={itemVariants}
                  className="border border-warehouse-border dark:border-warehouse-border-dark rounded-lg p-4 space-y-3"
                >
                  {/* Task Header */}
                  <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2">
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900 dark:text-gray-100">
                        {task.description}
                      </h4>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Task ID: {task.id}
                      </p>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <StatusChip status={task.priority} size="sm" />
                      <StatusChip status={task.status} />
                    </div>
                  </div>

                  {/* Task Details */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-sm">
                    {/* Robot Assignment */}
                    <div className="flex items-center space-x-2">
                      <User className="h-4 w-4 text-gray-400" />
                      <span className="text-gray-600 dark:text-gray-400">
                        {robot ? (
                          <span className="text-gray-900 dark:text-gray-100">
                            {robot.name}
                          </span>
                        ) : (
                          <span className="text-amber-600 dark:text-amber-400">
                            Unassigned
                          </span>
                        )}
                      </span>
                    </div>

                    {/* Route */}
                    <div className="flex items-center space-x-2 sm:col-span-2 lg:col-span-1">
                      <MapPin className="h-4 w-4 text-gray-400" />
                      <div className="flex items-center space-x-1">
                        <span className="text-gray-600 dark:text-gray-400">
                          {task.source}
                        </span>
                        <ArrowRight className="h-3 w-3 text-gray-400" />
                        <span className="text-gray-600 dark:text-gray-400">
                          {task.destination}
                        </span>
                      </div>
                    </div>

                    {/* Created Time */}
                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4 text-gray-400" />
                      <span className="text-gray-600 dark:text-gray-400">
                        {formatDate(task.createdAt)}
                      </span>
                    </div>
                  </div>

                  {/* Actions */}
                  {showActions && task.status !== 'Completed' && (
                    <div className="flex flex-wrap gap-2 pt-2 border-t border-warehouse-border dark:border-warehouse-border-dark">
                      {task.status === 'In-progress' && task.robotId && (
                        <button
                          onClick={() => handleCompleteTask(task.id, task.robotId)}
                          className="inline-flex items-center px-3 py-1.5 text-xs font-medium rounded-md bg-green-100 text-green-800 hover:bg-green-200 dark:bg-green-900 dark:text-green-300 dark:hover:bg-green-800 transition-colors"
                        >
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Mark Complete
                        </button>
                      )}

                      {task.status === 'Pending' && availableRobots.length > 0 && (
                        <select
                          onChange={(e) => {
                            if (e.target.value) {
                              handleAssignRobot(task.id, e.target.value)
                            }
                          }}
                          className="text-xs px-2 py-1.5 border border-warehouse-border dark:border-warehouse-border-dark rounded-md bg-warehouse-card dark:bg-warehouse-card-dark text-gray-900 dark:text-gray-100"
                          defaultValue=""
                        >
                          <option value="">Assign Robot</option>
                          {availableRobots.map(robot => (
                            <option key={robot.id} value={robot.id}>
                              {robot.name}
                            </option>
                          ))}
                        </select>
                      )}
                    </div>
                  )}

                  {/* Completed info */}
                  {task.status === 'Completed' && task.completedAt && (
                    <div className="text-xs text-green-600 dark:text-green-400 pt-2 border-t border-warehouse-border dark:border-warehouse-border-dark">
                      ✓ Completed on {formatDate(task.completedAt)}
                    </div>
                  )}
                </motion.div>
              )
            })}
          </motion.div>
        ) : (
          <div className="text-center py-8">
            <div className="text-gray-400 dark:text-gray-600 text-3xl mb-2">📋</div>
            <h4 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-1">
              No tasks found
            </h4>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {searchTerm 
                ? 'Try adjusting your search criteria.' 
                : 'No tasks available in this category.'}
            </p>
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center pt-4 border-t border-warehouse-border dark:border-warehouse-border-dark">
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
            />
          </div>
        )}
      </div>
    </Card>
  )
}

export default TaskList