import { useState, useMemo } from 'react'
import { motion } from 'framer-motion'
import { AlertTriangle, Package, MapPin, DollarSign } from 'lucide-react'
import Card from '../common/Card'
import SearchInput from '../common/SearchInput'
import Pagination from '../common/Pagination'
import Badge from '../common/Badge'

/**
 * Inventory table with search, filtering, and low stock highlighting
 * @param {Object} props
 * @param {Array} props.items - Inventory items to display
 * @param {Function} props.onItemClick - Click handler for items
 */
function InventoryTable({ items, onItemClick }) {
  const [searchTerm, setSearchTerm] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const [sortField, setSortField] = useState('name')
  const [sortDirection, setSortDirection] = useState('asc')
  const [filterCategory, setFilterCategory] = useState('All')
  const [showLowStockOnly, setShowLowStockOnly] = useState(false)
  const itemsPerPage = 10

  // Get unique categories
  const categories = useMemo(() => {
    const cats = [...new Set(items.map(item => item.category))].sort()
    return ['All', ...cats]
  }, [items])

  // Filter and sort items
  const filteredItems = useMemo(() => {
    let filtered = items.filter(item => {
      const matchesSearch = 
        item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.category.toLowerCase().includes(searchTerm.toLowerCase())
      
      const matchesCategory = filterCategory === 'All' || item.category === filterCategory
      const matchesLowStock = !showLowStockOnly || item.quantity <= item.minStock
      
      return matchesSearch && matchesCategory && matchesLowStock
    })

    // Sort items
    filtered.sort((a, b) => {
      let aVal = a[sortField]
      let bVal = b[sortField]
      
      if (typeof aVal === 'string') {
        aVal = aVal.toLowerCase()
        bVal = bVal.toLowerCase()
      }
      
      if (sortDirection === 'asc') {
        return aVal < bVal ? -1 : aVal > bVal ? 1 : 0
      } else {
        return aVal > bVal ? -1 : aVal < bVal ? 1 : 0
      }
    })

    return filtered
  }, [items, searchTerm, filterCategory, showLowStockOnly, sortField, sortDirection])

  // Pagination
  const totalPages = Math.ceil(filteredItems.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const paginatedItems = filteredItems.slice(startIndex, startIndex + itemsPerPage)

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc')
    } else {
      setSortField(field)
      setSortDirection('asc')
    }
  }

  const getSortIcon = (field) => {
    if (sortField !== field) return '↕️'
    return sortDirection === 'asc' ? '↑' : '↓'
  }

  const isLowStock = (item) => item.quantity <= item.minStock

  const tableVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { 
        duration: 0.3,
        staggerChildren: 0.05
      }
    }
  }

  const rowVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: { opacity: 1, x: 0 }
  }

  return (
    <Card>
      <div className="space-y-4">
        {/* Header and Controls */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
              Inventory Items
            </h3>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {filteredItems.length} item{filteredItems.length !== 1 ? 's' : ''} found
            </p>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col sm:flex-row gap-4">
            <SearchInput
              value={searchTerm}
              onChange={setSearchTerm}
              placeholder="Search items..."
              className="w-full sm:w-64"
            />
            
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="px-3 py-2 border border-warehouse-border dark:border-warehouse-border-dark rounded-md bg-warehouse-card dark:bg-warehouse-card-dark text-gray-900 dark:text-gray-100 text-sm"
            >
              {categories.map(category => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>

            <label className="flex items-center space-x-2 text-sm">
              <input
                type="checkbox"
                checked={showLowStockOnly}
                onChange={(e) => setShowLowStockOnly(e.target.checked)}
                className="rounded border-warehouse-border dark:border-warehouse-border-dark"
              />
              <span className="text-gray-700 dark:text-gray-300">Low stock only</span>
            </label>
          </div>
        </div>

        {/* Table */}
        {paginatedItems.length > 0 ? (
          <motion.div
            className="overflow-x-auto"
            variants={tableVariants}
            initial="hidden"
            animate="visible"
          >
            <table className="min-w-full divide-y divide-warehouse-border dark:divide-warehouse-border-dark">
              <thead className="bg-gray-50 dark:bg-gray-800">
                <tr>
                  <th
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                    onClick={() => handleSort('name')}
                  >
                    <div className="flex items-center space-x-1">
                      <Package className="h-4 w-4" />
                      <span>Item Name</span>
                      <span>{getSortIcon('name')}</span>
                    </div>
                  </th>
                  
                  <th
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                    onClick={() => handleSort('quantity')}
                  >
                    <div className="flex items-center space-x-1">
                      <span>Quantity</span>
                      <span>{getSortIcon('quantity')}</span>
                    </div>
                  </th>

                  <th
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                    onClick={() => handleSort('location')}
                  >
                    <div className="flex items-center space-x-1">
                      <MapPin className="h-4 w-4" />
                      <span>Location</span>
                      <span>{getSortIcon('location')}</span>
                    </div>
                  </th>

                  <th
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                    onClick={() => handleSort('category')}
                  >
                    <div className="flex items-center space-x-1">
                      <span>Category</span>
                      <span>{getSortIcon('category')}</span>
                    </div>
                  </th>

                  <th
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                    onClick={() => handleSort('unitCost')}
                  >
                    <div className="flex items-center space-x-1">
                      <DollarSign className="h-4 w-4" />
                      <span>Unit Cost</span>
                      <span>{getSortIcon('unitCost')}</span>
                    </div>
                  </th>

                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Status
                  </th>
                </tr>
              </thead>
              
              <tbody className="bg-warehouse-card dark:bg-warehouse-card-dark divide-y divide-warehouse-border dark:divide-warehouse-border-dark">
                {paginatedItems.map((item) => (
                  <motion.tr
                    key={item.id}
                    variants={rowVariants}
                    className={`hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors cursor-pointer ${
                      isLowStock(item) ? 'bg-red-50 dark:bg-red-900/20' : ''
                    }`}
                    onClick={() => onItemClick?.(item)}
                  >
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div>
                          <div className="text-sm font-medium text-gray-900 dark:text-gray-100">
                            {item.name}
                          </div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">
                            ID: {item.id}
                          </div>
                        </div>
                      </div>
                    </td>

                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-2">
                        <span className={`text-sm font-medium ${
                          isLowStock(item) 
                            ? 'text-red-600 dark:text-red-400' 
                            : 'text-gray-900 dark:text-gray-100'
                        }`}>
                          {item.quantity}
                        </span>
                        {isLowStock(item) && (
                          <AlertTriangle className="h-4 w-4 text-red-500" />
                        )}
                      </div>
                      <div className="text-xs text-gray-500 dark:text-gray-400">
                        Min: {item.minStock}
                      </div>
                    </td>

                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                      {item.location}
                    </td>

                    <td className="px-6 py-4 whitespace-nowrap">
                      <Badge variant="default" size="sm">
                        {item.category}
                      </Badge>
                    </td>

                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                      ${item.unitCost.toFixed(2)}
                    </td>

                    <td className="px-6 py-4 whitespace-nowrap">
                      {isLowStock(item) ? (
                        <Badge variant="danger" size="sm">
                          Low Stock
                        </Badge>
                      ) : (
                        <Badge variant="success" size="sm">
                          In Stock
                        </Badge>
                      )}
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </motion.div>
        ) : (
          <div className="text-center py-12">
            <div className="text-gray-400 dark:text-gray-600 text-4xl mb-4">📦</div>
            <h4 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
              No items found
            </h4>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {searchTerm || filterCategory !== 'All' || showLowStockOnly
                ? 'Try adjusting your search or filter criteria.'
                : 'No inventory items are currently in the system.'}
            </p>
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center pt-4 border-t border-warehouse-border dark:border-warehouse-border-dark">
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
            />
          </div>
        )}
      </div>
    </Card>
  )
}

export default InventoryTable