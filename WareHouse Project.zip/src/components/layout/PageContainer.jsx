import { motion } from 'framer-motion'

/**
 * Enhanced page container component for consistent layout with modern styling
 * @param {Object} props
 * @param {React.ReactNode} props.children - Page content
 * @param {string} props.title - Page title
 * @param {React.ReactNode} props.actions - Optional action buttons
 * @param {string} props.description - Optional page description
 */
function PageContainer({ children, title, actions, description }) {
  const headerVariants = {
    hidden: { opacity: 0, y: -20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: {
        duration: 0.5,
        ease: "easeOut"
      }
    }
  }

  const contentVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: {
        duration: 0.6,
        delay: 0.2,
        ease: "easeOut"
      }
    }
  }

  return (
    <div className="space-y-8">
      {/* Page header */}
      <motion.div 
        variants={headerVariants}
        initial="hidden"
        animate="visible"
        className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0"
      >
        <div className="space-y-2">
          <h1 className="text-3xl lg:text-4xl font-bold gradient-text">
            {title}
          </h1>
          {description && (
            <p className="text-gray-600 dark:text-gray-400 text-lg max-w-2xl">
              {description}
            </p>
          )}
        </div>
        {actions && (
          <motion.div 
            className="flex flex-wrap gap-3"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3, duration: 0.4 }}
          >
            {actions}
          </motion.div>
        )}
      </motion.div>

      {/* Decorative line */}
      <motion.div 
        className="h-px bg-gradient-to-r from-transparent via-gray-300 dark:via-gray-700 to-transparent"
        initial={{ scaleX: 0 }}
        animate={{ scaleX: 1 }}
        transition={{ delay: 0.4, duration: 0.8, ease: "easeOut" }}
      />

      {/* Page content */}
      <motion.div
        variants={contentVariants}
        initial="hidden"
        animate="visible"
      >
        {children}
      </motion.div>
    </div>
  )
}

export default PageContainer