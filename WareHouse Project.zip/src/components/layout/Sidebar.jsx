import { NavLink } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Bot, ClipboardList, Package, X, Zap, TrendingUp } from 'lucide-react'

/**
 * Sidebar navigation component
 * @param {Object} props
 * @param {boolean} props.isOpen - Whether sidebar is open on mobile
 * @param {Function} props.onClose - Function to close sidebar on mobile
 */
function Sidebar({ isOpen, onClose }) {
  const navigation = [
    {
      name: 'Robots',
      href: '/robots',
      icon: Bot,
      description: 'Monitor robot status and battery levels',
      gradient: 'from-blue-500 to-cyan-500'
    },
    {
      name: 'Tasks',
      href: '/tasks',
      icon: ClipboardList,
      description: 'Manage warehouse tasks and assignments',
      gradient: 'from-purple-500 to-pink-500'
    },
    {
      name: 'Inventory',
      href: '/inventory',
      icon: Package,
      description: 'Track inventory levels and locations',
      gradient: 'from-green-500 to-emerald-500'
    },
  ]

  const stats = [
    { label: 'Active Robots', value: '24', icon: Bot, change: '+2' },
    { label: 'Tasks Today', value: '156', icon: Zap, change: '+12%' },
  ]

  const itemVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: { opacity: 1, x: 0 }
  }

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed top-16 left-0 z-40 w-72 h-[calc(100vh-4rem)] bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl border-r border-white/20 dark:border-gray-700/20 shadow-xl transition-transform duration-300 ease-in-out overflow-y-auto ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } lg:translate-x-0`}
      >
        <div className="flex flex-col min-h-full">
          {/* Mobile header */}
          <div className="flex items-center justify-between p-6 border-b border-white/10 dark:border-gray-700/20 lg:hidden">
            <h2 className="text-lg font-semibold gradient-text">
              Navigation
            </h2>
            <button
              onClick={onClose}
              className="p-2 rounded-lg text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-100 hover:bg-gray-100/50 dark:hover:bg-gray-800/50 transition-all duration-200 transform hover:scale-105"
              aria-label="Close sidebar"
            >
              <X size={20} />
            </button>
          </div>

          {/* Quick Stats */}
          <div className="p-6 space-y-4 border-b border-white/10 dark:border-gray-700/20">
            <h3 className="text-sm font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wide">
              Quick Stats
            </h3>
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                variants={itemVariants}
                initial="hidden"
                animate="visible"
                transition={{ delay: index * 0.1 }}
                className="flex items-center justify-between p-3 rounded-xl bg-gradient-to-r from-white/50 to-gray-50/50 dark:from-gray-800/50 dark:to-gray-700/50 backdrop-blur-sm border border-white/20 dark:border-gray-600/20"
              >
                <div className="flex items-center space-x-3">
                  <div className="p-2 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 text-white">
                    <stat.icon size={16} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">
                      {stat.value}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {stat.label}
                    </p>
                  </div>
                </div>
                <div className="flex items-center text-green-600 dark:text-green-400">
                  <TrendingUp size={12} />
                  <span className="text-xs font-medium ml-1">{stat.change}</span>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-6 space-y-3">
            <h3 className="text-sm font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wide mb-4">
              Navigation
            </h3>
            {navigation.map((item, index) => (
              <motion.div
                key={item.name}
                variants={itemVariants}
                initial="hidden"
                animate="visible"
                transition={{ delay: 0.2 + index * 0.1 }}
              >
                <NavLink
                  to={item.href}
                  onClick={() => window.innerWidth < 1024 && onClose()}
                  className={({ isActive }) =>
                    `nav-link ${isActive ? 'nav-link-active' : 'nav-link-inactive'}`
                  }
                >
                  {({ isActive }) => (
                    <>
                      <div className={`p-2 rounded-lg mr-3 transition-all duration-200 ${
                        isActive 
                          ? `bg-gradient-to-br ${item.gradient} text-white shadow-md` 
                          : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-gray-100'
                      }`}>
                        <item.icon size={18} />
                      </div>
                      <div className="flex-1">
                        <div className="font-medium">{item.name}</div>
                        <div className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                          {item.description}
                        </div>
                      </div>
                      {isActive && (
                        <motion.div
                          layoutId="activeIndicator"
                          className="w-1 h-8 bg-gradient-to-b from-primary-400 to-primary-600 rounded-full"
                          initial={false}
                          transition={{ type: "spring", stiffness: 350, damping: 30 }}
                        />
                      )}
                    </>
                  )}
                </NavLink>
              </motion.div>
            ))}
          </nav>

          {/* Footer */}
          <motion.div 
            variants={itemVariants}
            initial="hidden"
            animate="visible"
            transition={{ delay: 0.5 }}
            className="p-6 border-t border-white/10 dark:border-gray-700/20"
          >
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-xl p-4 backdrop-blur-sm border border-blue-200/20 dark:border-blue-700/20">
              <p className="text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                Warehouse Dashboard
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                Version 1.0 • Real-time monitoring
              </p>
            </div>
          </motion.div>
        </div>
      </aside>
    </>
  )
}

export default Sidebar