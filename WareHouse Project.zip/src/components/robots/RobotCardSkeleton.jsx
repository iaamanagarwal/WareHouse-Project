import { motion } from 'framer-motion'
import Card from '../common/Card'
import SkeletonLoader from '../common/SkeletonLoader'

/**
 * Loading skeleton for robot cards
 */
function RobotCardSkeleton() {
  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: {
        duration: 0.4,
        ease: "easeOut"
      }
    }
  }

  return (
    <motion.div
      variants={cardVariants}
      initial="hidden"
      animate="visible"
    >
      <Card className="h-full">
        <div className="space-y-5">
          {/* Header */}
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-3">
              <SkeletonLoader variant="avatar" className="!rounded-xl" />
              <div className="space-y-2">
                <SkeletonLoader variant="title" className="w-24" />
                <SkeletonLoader variant="text" className="w-16 h-3" />
              </div>
            </div>
            <SkeletonLoader variant="button" className="w-16 h-6 !rounded-full" />
          </div>

          {/* Battery Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <SkeletonLoader variant="text" className="w-16 h-4" />
              <SkeletonLoader variant="text" className="w-8 h-4" />
            </div>
            <SkeletonLoader variant="text" className="w-full h-2.5 !rounded-full" />
          </div>

          {/* Location */}
          <div className="flex items-center justify-between">
            <SkeletonLoader variant="text" className="w-20 h-4" />
            <SkeletonLoader variant="text" className="w-12 h-4" />
          </div>
        </div>
      </Card>
    </motion.div>
  )
}

export default RobotCardSkeleton