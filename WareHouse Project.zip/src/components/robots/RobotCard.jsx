import { motion } from 'framer-motion'
import { Bot, Battery, MapPin, Zap, Activity } from 'lucide-react'
import Card from '../common/Card'
import StatusChip from '../common/StatusChip'

/**
 * Individual robot card component
 * @param {Object} props
 * @param {Object} props.robot - Robot data object
 * @param {Function} props.onClick - Click handler
 */
function RobotCard({ robot, onClick }) {
  const getBatteryColor = (level) => {
    if (level >= 80) return 'from-green-400 to-emerald-500'
    if (level >= 50) return 'from-yellow-400 to-orange-500'
    if (level >= 20) return 'from-orange-400 to-red-500'
    return 'from-red-500 to-red-600'
  }

  const getBatteryIcon = (level) => {
    if (level >= 80) return <Zap className="h-3 w-3 text-green-600" />
    if (level >= 20) return <Battery className="h-3 w-3 text-yellow-600" />
    return <Activity className="h-3 w-3 text-red-600" />
  }

  const cardVariants = {
    hidden: { opacity: 0, y: 20, scale: 0.95 },
    visible: { 
      opacity: 1, 
      y: 0, 
      scale: 1,
      transition: {
        duration: 0.4,
        ease: "easeOut"
      }
    },
    hover: {
      y: -8,
      scale: 1.02,
      transition: {
        duration: 0.2,
        ease: "easeOut"
      }
    }
  }

  const iconVariants = {
    idle: { rotate: 0 },
    hover: { rotate: 360, transition: { duration: 0.6 } }
  }

  return (
    <motion.div
      variants={cardVariants}
      initial="hidden"
      animate="visible"
      whileHover="hover"
      className="group"
    >
      <Card 
        hoverable 
        onClick={onClick} 
        className="h-full overflow-hidden relative bg-gradient-to-br from-white/80 to-gray-50/50 dark:from-gray-800/80 dark:to-gray-900/50 backdrop-blur-sm border border-white/30 dark:border-gray-600/30 shadow-sm hover:shadow-lg"
      >
        {/* Background Pattern */}
        <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-blue-500/5 to-purple-500/5 rounded-full -translate-y-12 translate-x-12 group-hover:scale-150 transition-transform duration-500"></div>
        
        <div className="space-y-5 relative z-10">
          {/* Header */}
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-3">
              <motion.div 
                variants={iconVariants}
                className="p-3 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl shadow-md group-hover:shadow-lg transition-shadow duration-300"
              >
                <Bot className="h-5 w-5 text-white" />
              </motion.div>
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-gray-100 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors duration-200">
                  {robot.name}
                </h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {robot.id}
                </p>
              </div>
            </div>
            <StatusChip status={robot.status} size="sm" />
          </div>

          {/* Battery Level */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                {getBatteryIcon(robot.batteryLevel)}
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Battery
                </span>
              </div>
              <span className="text-sm font-semibold text-gray-900 dark:text-gray-100">
                {robot.batteryLevel}%
              </span>
            </div>
            
            <div className="relative">
              <div className="w-full bg-gray-200/60 dark:bg-gray-700/60 rounded-full h-2.5 overflow-hidden backdrop-blur-sm">
                <motion.div
                  className={`h-full rounded-full bg-gradient-to-r ${getBatteryColor(robot.batteryLevel)} shadow-inner relative overflow-hidden`}
                  initial={{ width: 0 }}
                  animate={{ width: `${robot.batteryLevel}%` }}
                  transition={{ duration: 1.2, ease: "easeOut", delay: 0.2 }}
                >
                  {/* Shimmer effect */}
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                    animate={{ x: ['-100%', '100%'] }}
                    transition={{ 
                      duration: 2,
                      repeat: Infinity,
                      ease: "linear",
                      delay: 1.5
                    }}
                  />
                </motion.div>
              </div>
              
              {/* Battery status indicator */}
              {robot.batteryLevel <= 20 && (
                <motion.div
                  animate={{ opacity: [0.5, 1, 0.5] }}
                  transition={{ duration: 1, repeat: Infinity }}
                  className="absolute -top-1 -right-1 h-3 w-3 bg-red-500 rounded-full border-2 border-white dark:border-gray-800"
                />
              )}
            </div>
          </div>

          {/* Location */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
              <div className="p-1.5 bg-gray-100 dark:bg-gray-800 rounded-lg">
                <MapPin className="h-3.5 w-3.5" />
              </div>
              <span>{robot.location}</span>
            </div>
            
            {/* Activity indicator */}
            <div className="flex items-center space-x-1">
              <motion.div
                animate={{ 
                  scale: robot.status === 'busy' ? [1, 1.2, 1] : 1,
                  opacity: robot.status === 'busy' ? [0.7, 1, 0.7] : 1
                }}
                transition={{ 
                  duration: 1.5, 
                  repeat: robot.status === 'busy' ? Infinity : 0
                }}
                className={`h-2 w-2 rounded-full ${
                  robot.status === 'busy' 
                    ? 'bg-amber-400' 
                    : robot.status === 'charging'
                    ? 'bg-green-400'
                    : 'bg-gray-300 dark:bg-gray-600'
                }`}
              />
              <span className="text-xs text-gray-500 dark:text-gray-400 capitalize">
                {robot.status}
              </span>
            </div>
          </div>

          {/* Hover effect overlay */}
          <motion.div
            className="absolute inset-0 bg-gradient-to-br from-blue-500/0 to-purple-500/0 group-hover:from-blue-500/5 group-hover:to-purple-500/5 rounded-xl transition-all duration-300 pointer-events-none"
            initial={false}
          />
        </div>
      </Card>
    </motion.div>
  )
}

export default RobotCard