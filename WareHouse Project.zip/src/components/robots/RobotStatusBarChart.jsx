import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts'
import { motion } from 'framer-motion'
import Card from '../common/Card'

/**
 * Bar chart showing robot status distribution
 * @param {Object} props
 * @param {Array} props.data - Chart data array
 */
function RobotStatusBarChart({ data }) {
  const statusColors = {
    Idle: '#6b7280',    // gray-500
    Busy: '#f59e0b',    // amber-500
    Charging: '#10b981'  // emerald-500
  }

  const chartVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: { 
      opacity: 1, 
      scale: 1,
      transition: { 
        duration: 0.5,
        ease: "easeOut"
      }
    }
  }

  return (
    <motion.div
      variants={chartVariants}
      initial="hidden"
      animate="visible"
    >
      <Card>
        <div className="space-y-4">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
              Robot Status Distribution
            </h3>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Current status breakdown of all robots
            </p>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid 
                  strokeDasharray="3 3" 
                  stroke="#e5e7eb"
                  className="dark:stroke-gray-700"
                />
                <XAxis 
                  dataKey="status" 
                  stroke="#6b7280"
                  tick={{ fill: '#6b7280', fontSize: 12 }}
                />
                <YAxis 
                  stroke="#6b7280"
                  tick={{ fill: '#6b7280', fontSize: 12 }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    border: '1px solid #e5e7eb',
                    borderRadius: '6px',
                    fontSize: '14px'
                  }}
                  wrapperClassName="dark:!bg-gray-800 dark:!border-gray-700"
                  formatter={(value, name) => [value, 'Count']}
                  labelFormatter={(label) => `Status: ${label}`}
                />
                <Bar 
                  dataKey="count" 
                  radius={[4, 4, 0, 0]}
                  animationDuration={800}
                  animationBegin={200}
                >
                  {data.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={statusColors[entry.status] || '#6b7280'} 
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Legend */}
          <div className="flex flex-wrap gap-4 justify-center">
            {Object.entries(statusColors).map(([status, color]) => (
              <div key={status} className="flex items-center space-x-2">
                <div 
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: color }}
                />
                <span className="text-sm text-gray-600 dark:text-gray-400">
                  {status}
                </span>
              </div>
            ))}
          </div>
        </div>
      </Card>
    </motion.div>
  )
}

export default RobotStatusBarChart