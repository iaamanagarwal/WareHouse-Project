import { ChevronLeft, ChevronRight, MoreHorizontal } from 'lucide-react'
import { motion } from 'framer-motion'

/**
 * Enhanced pagination component with modern styling and animations
 * @param {Object} props
 * @param {number} props.currentPage - Current active page (1-based)
 * @param {number} props.totalPages - Total number of pages
 * @param {Function} props.onPageChange - Page change handler
 * @param {number} props.maxVisiblePages - Maximum number of page buttons to show
 */
function Pagination({ 
  currentPage, 
  totalPages, 
  onPageChange, 
  maxVisiblePages = 5 
}) {
  if (totalPages <= 1) return null

  const getVisiblePages = () => {
    const half = Math.floor(maxVisiblePages / 2)
    let start = Math.max(1, currentPage - half)
    let end = Math.min(totalPages, start + maxVisiblePages - 1)
    
    if (end - start + 1 < maxVisiblePages) {
      start = Math.max(1, end - maxVisiblePages + 1)
    }
    
    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  const visiblePages = getVisiblePages()

  const buttonClass = (isActive = false, disabled = false) => {
    const baseClass = "relative inline-flex items-center justify-center min-w-[2.5rem] h-10 text-sm font-medium transition-all duration-200 backdrop-blur-sm"
    
    if (disabled) {
      return `${baseClass} text-gray-400 dark:text-gray-600 cursor-not-allowed bg-gray-100/50 dark:bg-gray-800/50`
    }
    
    if (isActive) {
      return `${baseClass} bg-gradient-to-r from-primary-600 to-purple-600 text-white shadow-md hover:shadow-lg hover:scale-105 focus:z-10 focus:ring-2 focus:ring-primary-500 focus:outline-none`
    }
    
    return `${baseClass} text-gray-700 dark:text-gray-300 bg-white/70 dark:bg-gray-800/70 border border-white/30 dark:border-gray-600/30 hover:bg-white/90 dark:hover:bg-gray-700/90 hover:scale-105 focus:z-10 focus:ring-2 focus:ring-primary-500 focus:outline-none shadow-sm hover:shadow-md`
  }

  const buttonVariants = {
    inactive: { scale: 1 },
    active: { scale: 1.1 },
    hover: { scale: 1.05 }
  }

  return (
    <nav className="flex items-center justify-center" aria-label="Pagination">
      {/* Mobile pagination */}
      <div className="flex items-center space-x-2 sm:hidden">
        <motion.button
          onClick={() => onPageChange(currentPage - 1)}
          disabled={currentPage === 1}
          className={`${buttonClass(false, currentPage === 1)} px-4 rounded-lg`}
          whileHover={currentPage !== 1 ? "hover" : ""}
          whileTap={currentPage !== 1 ? { scale: 0.95 } : {}}
          variants={buttonVariants}
        >
          <ChevronLeft className="h-4 w-4 mr-1" />
          Previous
        </motion.button>
        
        <div className="px-4 py-2 bg-white/70 dark:bg-gray-800/70 backdrop-blur-sm rounded-lg border border-white/30 dark:border-gray-600/30">
          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
            {currentPage} of {totalPages}
          </span>
        </div>
        
        <motion.button
          onClick={() => onPageChange(currentPage + 1)}
          disabled={currentPage === totalPages}
          className={`${buttonClass(false, currentPage === totalPages)} px-4 rounded-lg`}
          whileHover={currentPage !== totalPages ? "hover" : ""}
          whileTap={currentPage !== totalPages ? { scale: 0.95 } : {}}
          variants={buttonVariants}
        >
          Next
          <ChevronRight className="h-4 w-4 ml-1" />
        </motion.button>
      </div>

      {/* Desktop pagination */}
      <div className="hidden sm:flex items-center space-x-1">
        {/* Previous button */}
        <motion.button
          onClick={() => onPageChange(currentPage - 1)}
          disabled={currentPage === 1}
          className={`${buttonClass(false, currentPage === 1)} rounded-lg px-3`}
          whileHover={currentPage !== 1 ? "hover" : ""}
          whileTap={currentPage !== 1 ? { scale: 0.95 } : {}}
          variants={buttonVariants}
          aria-label="Previous page"
        >
          <ChevronLeft className="h-4 w-4" />
        </motion.button>

        {/* First page */}
        {visiblePages[0] > 1 && (
          <>
            <motion.button
              onClick={() => onPageChange(1)}
              className={`${buttonClass(currentPage === 1)} rounded-lg`}
              whileHover="hover"
              whileTap={{ scale: 0.95 }}
              variants={buttonVariants}
              animate={currentPage === 1 ? "active" : "inactive"}
            >
              1
            </motion.button>
            {visiblePages[0] > 2 && (
              <div className="flex items-center justify-center min-w-[2.5rem] h-10 text-gray-500 dark:text-gray-400">
                <MoreHorizontal className="h-4 w-4" />
              </div>
            )}
          </>
        )}

        {/* Visible page numbers */}
        {visiblePages.map((page) => (
          <motion.button
            key={page}
            onClick={() => onPageChange(page)}
            className={`${buttonClass(currentPage === page)} rounded-lg`}
            whileHover={currentPage !== page ? "hover" : ""}
            whileTap={{ scale: 0.95 }}
            variants={buttonVariants}
            animate={currentPage === page ? "active" : "inactive"}
            aria-current={currentPage === page ? 'page' : undefined}
            layoutId={currentPage === page ? "activePage" : undefined}
          >
            {page}
          </motion.button>
        ))}

        {/* Last page */}
        {visiblePages[visiblePages.length - 1] < totalPages && (
          <>
            {visiblePages[visiblePages.length - 1] < totalPages - 1 && (
              <div className="flex items-center justify-center min-w-[2.5rem] h-10 text-gray-500 dark:text-gray-400">
                <MoreHorizontal className="h-4 w-4" />
              </div>
            )}
            <motion.button
              onClick={() => onPageChange(totalPages)}
              className={`${buttonClass(currentPage === totalPages)} rounded-lg`}
              whileHover="hover"
              whileTap={{ scale: 0.95 }}
              variants={buttonVariants}
              animate={currentPage === totalPages ? "active" : "inactive"}
            >
              {totalPages}
            </motion.button>
          </>
        )}

        {/* Next button */}
        <motion.button
          onClick={() => onPageChange(currentPage + 1)}
          disabled={currentPage === totalPages}
          className={`${buttonClass(false, currentPage === totalPages)} rounded-lg px-3`}
          whileHover={currentPage !== totalPages ? "hover" : ""}
          whileTap={currentPage !== totalPages ? { scale: 0.95 } : {}}
          variants={buttonVariants}
          aria-label="Next page"
        >
          <ChevronRight className="h-4 w-4" />
        </motion.button>
      </div>

      {/* Page info */}
      <div className="hidden lg:block ml-8">
        <div className="px-4 py-2 bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm rounded-lg border border-white/20 dark:border-gray-600/20">
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Page <span className="font-semibold text-gray-900 dark:text-gray-100">{currentPage}</span> of{' '}
            <span className="font-semibold text-gray-900 dark:text-gray-100">{totalPages}</span>
          </p>
        </div>
      </div>
    </nav>
  )
}

export default Pagination