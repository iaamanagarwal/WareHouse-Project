import { motion } from 'framer-motion'

/**
 * Enhanced skeleton loader component for loading states
 * @param {Object} props
 * @param {string} props.variant - Skeleton variant (text, card, avatar, etc.)
 * @param {string} props.className - Additional CSS classes
 * @param {number} props.lines - Number of lines for text variant
 * @param {number} props.count - Number of skeleton items to render
 * @param {boolean} props.animated - Whether to show shimmer animation
 */
function SkeletonLoader({ 
  variant = 'text', 
  className = '', 
  lines = 1, 
  count = 1, 
  animated = true 
}) {
  const shimmerVariants = {
    initial: { x: '-100%' },
    animate: {
      x: '100%',
      transition: {
        duration: 1.5,
        repeat: Infinity,
        ease: "easeInOut",
        delay: Math.random() * 0.5 // Add random delay for more natural feel
      }
    }
  }

  const baseClasses = 'bg-gray-200/60 dark:bg-gray-700/60 rounded animate-pulse relative overflow-hidden'

  const getVariantClasses = () => {
    switch (variant) {
      case 'card':
        return 'h-48 w-full'
      case 'robot-card':
        return 'h-64 w-full'
      case 'table-row':
        return 'h-12 w-full'
      case 'avatar':
        return 'h-12 w-12 rounded-full flex-shrink-0'
      case 'text':
        return 'h-4 w-full'
      case 'text-sm':
        return 'h-3 w-full'
      case 'title':
        return 'h-6 w-3/4'
      case 'subtitle':
        return 'h-5 w-1/2'
      case 'button':
        return 'h-10 w-24 rounded-lg'
      case 'button-lg':
        return 'h-12 w-32 rounded-lg'
      case 'chart':
        return 'h-64 w-full'
      case 'input':
        return 'h-11 w-full rounded-lg'
      case 'badge':
        return 'h-6 w-16 rounded-full'
      case 'progress':
        return 'h-2 w-full rounded-full'
      case 'image':
        return 'h-32 w-32 rounded-lg'
      default:
        return 'h-4 w-full'
    }
  }

  const SkeletonItem = ({ className: itemClassName = '', delay = 0 }) => (
    <div className={`${baseClasses} ${getVariantClasses()} ${itemClassName}`}>
      {animated && (
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 dark:via-white/10 to-transparent"
          variants={shimmerVariants}
          initial="initial"
          animate="animate"
          style={{ animationDelay: `${delay}ms` }}
        />
      )}
    </div>
  )

  // Multiple items (like a grid or list)
  if (count > 1) {
    return (
      <div className={`space-y-3 ${className}`}>
        {Array.from({ length: count }).map((_, index) => (
          <SkeletonItem 
            key={index} 
            delay={index * 100}
          />
        ))}
      </div>
    )
  }

  // Text with multiple lines
  if (variant === 'text' && lines > 1) {
    return (
      <div className={`space-y-2 ${className}`}>
        {Array.from({ length: lines }).map((_, index) => (
          <SkeletonItem 
            key={index} 
            className={index === lines - 1 ? 'w-2/3' : ''}
            delay={index * 100}
          />
        ))}
      </div>
    )
  }

  return <SkeletonItem className={className} />
}

export default SkeletonLoader