import { motion } from 'framer-motion'
import { Circle } from 'lucide-react'

/**
 * Enhanced status badge component with modern styling and animations
 * @param {Object} props
 * @param {string} props.status - Status value (idle, busy, charging, pending, in-progress, completed)
 * @param {string} props.variant - Visual variant (default, outline, glow)
 * @param {string} props.size - Size variant (sm, md, lg)
 * @param {boolean} props.animated - Whether to show animations
 */
function StatusChip({ status, variant = 'default', size = 'md', animated = true }) {
  const statusLower = status?.toLowerCase() || ''
  
  const baseClasses = 'status-chip backdrop-blur-sm'
  
  const sizeClasses = {
    sm: 'text-xs px-3 py-1.5',
    md: 'text-sm px-3.5 py-2',
    lg: 'text-base px-4 py-2.5'
  }
  
  const colorClasses = {
    idle: {
      default: 'bg-gray-100/80 text-gray-700 border-gray-200/50 dark:bg-gray-800/80 dark:text-gray-300 dark:border-gray-700/50',
      outline: 'border-2 border-gray-300/60 text-gray-700 bg-gray-50/50 dark:border-gray-600/60 dark:text-gray-400 dark:bg-gray-900/50',
      glow: 'bg-gray-100/80 text-gray-700 border-gray-200/50 shadow-glow dark:bg-gray-800/80 dark:text-gray-300 dark:border-gray-700/50'
    },
    busy: {
      default: 'bg-gradient-to-r from-amber-100/80 to-orange-100/80 text-amber-800 border-amber-200/50 dark:from-amber-900/80 dark:to-orange-900/80 dark:text-amber-300 dark:border-amber-800/50',
      outline: 'border-2 border-amber-300/60 text-amber-700 bg-amber-50/50 dark:border-amber-600/60 dark:text-amber-400 dark:bg-amber-900/30',
      glow: 'bg-gradient-to-r from-amber-100/80 to-orange-100/80 text-amber-800 border-amber-200/50 shadow-lg dark:from-amber-900/80 dark:to-orange-900/80 dark:text-amber-300 dark:border-amber-800/50'
    },
    charging: {
      default: 'bg-gradient-to-r from-green-100/80 to-emerald-100/80 text-green-800 border-green-200/50 dark:from-green-900/80 dark:to-emerald-900/80 dark:text-green-300 dark:border-green-800/50',
      outline: 'border-2 border-green-300/60 text-green-700 bg-green-50/50 dark:border-green-600/60 dark:text-green-400 dark:bg-green-900/30',
      glow: 'bg-gradient-to-r from-green-100/80 to-emerald-100/80 text-green-800 border-green-200/50 shadow-lg dark:from-green-900/80 dark:to-emerald-900/80 dark:text-green-300 dark:border-green-800/50'
    },
    pending: {
      default: 'bg-gray-100/80 text-gray-700 border-gray-200/50 dark:bg-gray-800/80 dark:text-gray-300 dark:border-gray-700/50',
      outline: 'border-2 border-gray-300/60 text-gray-700 bg-gray-50/50 dark:border-gray-600/60 dark:text-gray-400 dark:bg-gray-900/50',
      glow: 'bg-gray-100/80 text-gray-700 border-gray-200/50 shadow-lg dark:bg-gray-800/80 dark:text-gray-300 dark:border-gray-700/50'
    },
    'in-progress': {
      default: 'bg-gradient-to-r from-blue-100/80 to-indigo-100/80 text-blue-800 border-blue-200/50 dark:from-blue-900/80 dark:to-indigo-900/80 dark:text-blue-300 dark:border-blue-800/50',
      outline: 'border-2 border-blue-300/60 text-blue-700 bg-blue-50/50 dark:border-blue-600/60 dark:text-blue-400 dark:bg-blue-900/30',
      glow: 'bg-gradient-to-r from-blue-100/80 to-indigo-100/80 text-blue-800 border-blue-200/50 shadow-lg dark:from-blue-900/80 dark:to-indigo-900/80 dark:text-blue-300 dark:border-blue-800/50'
    },
    completed: {
      default: 'bg-gradient-to-r from-green-100/80 to-emerald-100/80 text-green-800 border-green-200/50 dark:from-green-900/80 dark:to-emerald-900/80 dark:text-green-300 dark:border-green-800/50',
      outline: 'border-2 border-green-300/60 text-green-700 bg-green-50/50 dark:border-green-600/60 dark:text-green-400 dark:bg-green-900/30',
      glow: 'bg-gradient-to-r from-green-100/80 to-emerald-100/80 text-green-800 border-green-200/50 shadow-lg dark:from-green-900/80 dark:to-emerald-900/80 dark:text-green-300 dark:border-green-800/50'
    },
    high: {
      default: 'bg-gradient-to-r from-red-100/80 to-rose-100/80 text-red-800 border-red-200/50 dark:from-red-900/80 dark:to-rose-900/80 dark:text-red-300 dark:border-red-800/50',
      outline: 'border-2 border-red-300/60 text-red-700 bg-red-50/50 dark:border-red-600/60 dark:text-red-400 dark:bg-red-900/30',
      glow: 'bg-gradient-to-r from-red-100/80 to-rose-100/80 text-red-800 border-red-200/50 shadow-lg dark:from-red-900/80 dark:to-rose-900/80 dark:text-red-300 dark:border-red-800/50'
    },
    medium: {
      default: 'bg-gradient-to-r from-yellow-100/80 to-amber-100/80 text-yellow-800 border-yellow-200/50 dark:from-yellow-900/80 dark:to-amber-900/80 dark:text-yellow-300 dark:border-yellow-800/50',
      outline: 'border-2 border-yellow-300/60 text-yellow-700 bg-yellow-50/50 dark:border-yellow-600/60 dark:text-yellow-400 dark:bg-yellow-900/30',
      glow: 'bg-gradient-to-r from-yellow-100/80 to-amber-100/80 text-yellow-800 border-yellow-200/50 shadow-lg dark:from-yellow-900/80 dark:to-amber-900/80 dark:text-yellow-300 dark:border-yellow-800/50'
    },
    low: {
      default: 'bg-gradient-to-r from-blue-100/80 to-sky-100/80 text-blue-800 border-blue-200/50 dark:from-blue-900/80 dark:to-sky-900/80 dark:text-blue-300 dark:border-blue-800/50',
      outline: 'border-2 border-blue-300/60 text-blue-700 bg-blue-50/50 dark:border-blue-600/60 dark:text-blue-400 dark:bg-blue-900/30',
      glow: 'bg-gradient-to-r from-blue-100/80 to-sky-100/80 text-blue-800 border-blue-200/50 shadow-lg dark:from-blue-900/80 dark:to-sky-900/80 dark:text-blue-300 dark:border-blue-800/50'
    }
  }

  const getActivityIndicator = (status) => {
    if (status === 'busy') return 'animate-pulse'
    if (status === 'charging') return 'animate-bounce'
    if (status === 'in-progress') return 'animate-pulse'
    return ''
  }

  const selectedColors = colorClasses[statusLower] || colorClasses['pending']
  const colorClass = selectedColors[variant] || selectedColors['default']
  
  const chipVariants = {
    initial: { scale: 0.8, opacity: 0 },
    animate: { 
      scale: 1, 
      opacity: 1,
      transition: { duration: 0.2, ease: "easeOut" }
    },
    hover: { 
      scale: 1.05,
      transition: { duration: 0.1 }
    }
  }

  return (
    <motion.span
      variants={animated ? chipVariants : {}}
      initial={animated ? "initial" : false}
      animate={animated ? "animate" : false}
      whileHover={animated ? "hover" : false}
      className={`${baseClasses} ${sizeClasses[size]} ${colorClass} relative overflow-hidden group`}
    >
      <div className="flex items-center space-x-2">
        <Circle 
          size={8} 
          className={`fill-current ${getActivityIndicator(statusLower)}`} 
        />
        <span className="font-semibold">{status}</span>
      </div>
      
      {/* Shimmer effect for active states */}
      {(statusLower === 'busy' || statusLower === 'in-progress' || statusLower === 'charging') && (
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
          animate={{ x: ['-100%', '100%'] }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "linear"
          }}
        />
      )}
      
      {/* Hover effect */}
      <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/10 to-white/0 opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
    </motion.span>
  )
}

export default StatusChip