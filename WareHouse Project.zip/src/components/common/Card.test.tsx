import { describe, it, expect, vi } from 'vitest'
import { render, screen } from '../../test/utils'
import Card from './Card'

describe('Card Component', () => {
  it('renders children correctly', () => {
    render(
      <Card>
        <h2>Test Content</h2>
        <p>This is a test</p>
      </Card>
    )

    expect(screen.getByText('Test Content')).toBeInTheDocument()
    expect(screen.getByText('This is a test')).toBeInTheDocument()
  })

  it('applies custom className', () => {
    const { container } = render(
      <Card className="custom-class">Test</Card>
    )

    expect(container.firstChild).toHaveClass('custom-class')
  })

  it('handles click events when clickable', () => {
    const handleClick = vi.fn()
    render(
      <Card onClick={handleClick}>Clickable Card</Card>
    )

    const card = screen.getByText('Clickable Card').parentElement
    card?.click()

    expect(handleClick).toHaveBeenCalledTimes(1)
  })
})