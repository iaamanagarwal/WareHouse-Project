import { Search, X } from 'lucide-react'
import { motion } from 'framer-motion'

/**
 * Enhanced search input component with modern styling and animations
 * @param {Object} props
 * @param {string} props.value - Current search value
 * @param {Function} props.onChange - Change handler
 * @param {string} props.placeholder - Input placeholder
 * @param {string} props.className - Additional CSS classes
 */
function SearchInput({ value, onChange, placeholder = 'Search...', className = '' }) {
  const handleClear = () => {
    onChange('')
  }

  return (
    <div className={`relative ${className}`}>
      <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
        <Search className="h-5 w-5 text-gray-400 group-focus-within:text-primary-500 transition-colors duration-200" />
      </div>
      
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="input-modern w-full pl-12 pr-12 py-3.5 text-sm placeholder:text-gray-400 dark:placeholder:text-gray-500 group"
      />
      
      {value && (
        <motion.button
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.8 }}
          onClick={handleClear}
          className="absolute inset-y-0 right-0 pr-4 flex items-center text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors duration-200 hover:bg-gray-100/50 dark:hover:bg-gray-800/50 rounded-r-lg"
          aria-label="Clear search"
        >
          <X className="h-5 w-5" />
        </motion.button>
      )}
      
      {/* Focus ring with gradient */}
      <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-blue-500/0 via-purple-500/0 to-blue-500/0 group-focus-within:from-blue-500/20 group-focus-within:via-purple-500/10 group-focus-within:to-blue-500/20 transition-all duration-300 pointer-events-none -z-10 blur-sm"></div>
    </div>
  )
}

export default SearchInput