import { motion } from 'framer-motion'

/**
 * Enhanced reusable card component with modern glass-morphism and animations
 * @param {Object} props
 * @param {React.ReactNode} props.children - Card content
 * @param {string} props.className - Additional CSS classes
 * @param {Function} props.onClick - Click handler
 * @param {boolean} props.hoverable - Enable hover effects
 * @param {string} props.variant - Card variant (default, glass, gradient)
 */
function Card({ children, className = '', onClick, hoverable = false, variant = 'default' }) {
  const getVariantClasses = () => {
    switch (variant) {
      case 'glass':
        return 'glass-card'
      case 'gradient':
        return 'bg-gradient-to-br from-white/80 via-blue-50/50 to-purple-50/30 dark:from-gray-800/80 dark:via-blue-950/50 dark:to-purple-950/30 backdrop-blur-lg border border-white/30 dark:border-gray-600/30 shadow-lg'
      default:
        return 'card'
    }
  }

  const cardClasses = `${getVariantClasses()} p-6 ${className} ${
    hoverable || onClick ? 'cursor-pointer group' : ''
  }`

  const cardVariants = {
    initial: { 
      scale: 1,
      rotateX: 0,
      rotateY: 0,
    },
    hover: { 
      scale: hoverable ? 1.03 : 1,
      rotateX: hoverable ? 2 : 0,
      rotateY: hoverable ? 2 : 0,
      transition: {
        duration: 0.3,
        ease: "easeOut"
      }
    },
    tap: { 
      scale: 0.97,
      transition: {
        duration: 0.1
      }
    }
  }

  const shimmerVariants = {
    initial: { x: '-100%', opacity: 0 },
    hover: {
      x: '100%',
      opacity: [0, 0.5, 0],
      transition: {
        duration: 0.6,
        ease: "easeInOut"
      }
    }
  }

  if (onClick || hoverable) {
    return (
      <motion.div
        className={cardClasses}
        onClick={onClick}
        variants={cardVariants}
        initial="initial"
        whileHover="hover"
        whileTap="tap"
        style={{
          transformStyle: "preserve-3d",
          perspective: 1000,
        }}
      >
        <div className="relative overflow-hidden">
          {children}
          
          {/* Shimmer effect on hover */}
          {(hoverable || onClick) && (
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent pointer-events-none"
              variants={shimmerVariants}
              initial="initial"
            />
          )}
          
          {/* Subtle gradient overlay on hover */}
          <motion.div
            className="absolute inset-0 bg-gradient-to-br from-blue-500/0 via-purple-500/0 to-pink-500/0 group-hover:from-blue-500/5 group-hover:via-purple-500/3 group-hover:to-pink-500/5 rounded-xl transition-all duration-300 pointer-events-none"
            initial={false}
          />
        </div>
      </motion.div>
    )
  }

  return (
    <div className={cardClasses}>
      <div className="relative overflow-hidden">
        {children}
      </div>
    </div>
  )
}

export default Card