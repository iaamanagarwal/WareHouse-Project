import { useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { motion } from 'framer-motion'
import Card from '../common/Card'

/**
 * Simple 3D robot representation using Three.js
 */
function Robot3D({ position = [0, 0, 0], color = '#3b82f6', ...props }) {
  const meshRef = useRef()

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.01
      meshRef.current.position.y = Math.sin(state.clock.elapsedTime) * 0.1
    }
  })

  return (
    <group position={position} {...props}>
      {/* Robot Body */}
      <mesh ref={meshRef}>
        <boxGeometry args={[1, 1.2, 0.8]} />
        <meshStandardMaterial color={color} />
      </mesh>
      
      {/* Robot Head */}
      <mesh position={[0, 0.8, 0]}>
        <sphereGeometry args={[0.3]} />
        <meshStandardMaterial color={color} />
      </mesh>
      
      {/* Robot Eyes */}
      <mesh position={[-0.1, 0.9, 0.25]}>
        <sphereGeometry args={[0.05]} />
        <meshStandardMaterial color="white" />
      </mesh>
      <mesh position={[0.1, 0.9, 0.25]}>
        <sphereGeometry args={[0.05]} />
        <meshStandardMaterial color="white" />
      </mesh>
      
      {/* Robot Base/Wheels */}
      <mesh position={[0, -0.7, 0]}>
        <cylinderGeometry args={[0.6, 0.6, 0.2]} />
        <meshStandardMaterial color="#666" />
      </mesh>
    </group>
  )
}

/**
 * 3D warehouse visualization component
 * @param {Object} props
 * @param {Array} props.robots - Array of robot data
 * @param {string} props.selectedRobot - Selected robot ID
 */
function Warehouse3DView({ robots = [], selectedRobot }) {
  const getStatusColor = (status) => {
    switch (status) {
      case 'Idle': return '#6b7280'    // gray
      case 'Busy': return '#f59e0b'    // amber
      case 'Charging': return '#10b981' // green
      default: return '#3b82f6'        // blue
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
    >
      <Card>
        <div className="space-y-4">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
              3D Warehouse View
            </h3>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Interactive 3D representation of robots
            </p>
          </div>

          {/* 3D Scene */}
          <div className="h-64 w-full bg-gradient-to-b from-blue-100 to-blue-50 dark:from-blue-900 dark:to-blue-800 rounded-lg overflow-hidden">
            <Canvas camera={{ position: [5, 5, 5], fov: 60 }}>
              {/* Lighting */}
              <ambientLight intensity={0.4} />
              <pointLight position={[10, 10, 10]} intensity={1} />
              <directionalLight position={[-10, 10, 5]} intensity={0.5} />

              {/* Floor */}
              <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2, 0]}>
                <planeGeometry args={[20, 20]} />
                <meshStandardMaterial color="#e5e7eb" />
              </mesh>

              {/* Grid pattern on floor */}
              <gridHelper args={[20, 20, '#9ca3af', '#d1d5db']} position={[0, -1.9, 0]} />

              {/* Robots */}
              {robots.slice(0, 6).map((robot, index) => {
                const x = (index % 3) * 3 - 3
                const z = Math.floor(index / 3) * 3 - 1.5
                const isSelected = robot.id === selectedRobot
                
                return (
                  <Robot3D
                    key={robot.id}
                    position={[x, isSelected ? 0.5 : 0, z]}
                    color={getStatusColor(robot.status)}
                    scale={isSelected ? 1.2 : 1}
                  />
                )
              })}

              {/* Warehouse structures */}
              {/* Storage racks */}
              {[-6, 0, 6].map((x, i) => (
                <mesh key={i} position={[x, 1, -6]}>
                  <boxGeometry args={[1, 2, 4]} />
                  <meshStandardMaterial color="#8b5cf6" />
                </mesh>
              ))}
            </Canvas>
          </div>

          {/* Robot Status Legend */}
          <div className="flex flex-wrap gap-4 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-gray-500 rounded"></div>
              <span className="text-gray-700 dark:text-gray-300">Idle</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-amber-500 rounded"></div>
              <span className="text-gray-700 dark:text-gray-300">Busy</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-green-500 rounded"></div>
              <span className="text-gray-700 dark:text-gray-300">Charging</span>
            </div>
          </div>

          {/* Controls */}
          <div className="text-xs text-gray-500 dark:text-gray-400">
            <p>💡 Tip: Click and drag to rotate the view. Scroll to zoom in/out.</p>
            {selectedRobot && (
              <p className="mt-1 text-primary-600 dark:text-primary-400">
                Selected robot is highlighted and elevated in the 3D view.
              </p>
            )}
          </div>
        </div>
      </Card>
    </motion.div>
  )
}

export default Warehouse3DView