import { motion } from 'framer-motion'
import { Bot, Package } from 'lucide-react'
import useWarehouseStore from '../../store/useWarehouseStore'
import Card from '../common/Card'

/**
 * 2D warehouse map visualization showing robot and inventory locations
 * @param {Object} props
 * @param {string} props.selectedRobot - ID of selected robot to highlight
 * @param {Function} props.onRobotClick - Robot click handler
 */
function WarehouseMap({ selectedRobot, onRobotClick }) {
  const { robots, inventory } = useWarehouseStore()

  // Define warehouse grid layout (6x4 grid)
  const warehouseZones = [
    ['A1', 'A2', 'A3', 'Receiving Dock'],
    ['B1', 'B2', 'B3', 'Production Line 1'],
    ['C1', 'C2', 'C3', 'Production Line 2'],
    ['D1', 'D2', 'D3', 'Shipping Dock'],
    ['Charging Station 1', 'Charging Station 2', 'Charging Station 3', 'QC Lab'],
    ['Dock 1', 'Dock 2', 'Dock 3', 'Maintenance Area']
  ]

  // Group robots by location
  const robotsByLocation = robots.reduce((acc, robot) => {
    const location = robot.location
    if (!acc[location]) acc[location] = []
    acc[location].push(robot)
    return acc
  }, {})

  // Group inventory by location
  const inventoryByLocation = inventory.reduce((acc, item) => {
    const location = item.location
    if (!acc[location]) acc[location] = []
    acc[location].push(item)
    return acc
  }, {})

  const getZoneColor = (zone) => {
    const hasRobots = robotsByLocation[zone]?.length > 0
    const hasInventory = inventoryByLocation[zone]?.length > 0
    
    if (hasRobots && hasInventory) return 'bg-purple-100 dark:bg-purple-900 border-purple-300 dark:border-purple-700'
    if (hasRobots) return 'bg-blue-100 dark:bg-blue-900 border-blue-300 dark:border-blue-700'
    if (hasInventory) return 'bg-green-100 dark:bg-green-900 border-green-300 dark:border-green-700'
    return 'bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700'
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'Idle': return 'text-gray-600 dark:text-gray-400'
      case 'Busy': return 'text-amber-600 dark:text-amber-400'
      case 'Charging': return 'text-green-600 dark:text-green-400'
      default: return 'text-gray-600 dark:text-gray-400'
    }
  }

  return (
    <Card>
      <div className="space-y-4">
        {/* Header */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
            Warehouse Map
          </h3>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Live view of robot and inventory locations
          </p>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap gap-4 text-sm">
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-blue-100 dark:bg-blue-900 border border-blue-300 dark:border-blue-700 rounded"></div>
            <span className="text-gray-700 dark:text-gray-300">Robots Only</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-green-100 dark:bg-green-900 border border-green-300 dark:border-green-700 rounded"></div>
            <span className="text-gray-700 dark:text-gray-300">Inventory Only</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-purple-100 dark:bg-purple-900 border border-purple-300 dark:border-purple-700 rounded"></div>
            <span className="text-gray-700 dark:text-gray-300">Both</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded"></div>
            <span className="text-gray-700 dark:text-gray-300">Empty</span>
          </div>
        </div>

        {/* Warehouse Grid */}
        <div className="grid grid-cols-4 gap-2 aspect-[4/3] p-4 bg-gray-100 dark:bg-gray-800 rounded-lg">
          {warehouseZones.map((row, rowIndex) =>
            row.map((zone, colIndex) => (
              <motion.div
                key={zone}
                className={`${getZoneColor(zone)} border-2 rounded-lg p-2 relative overflow-hidden min-h-[80px] flex flex-col justify-between`}
                whileHover={{ scale: 1.02 }}
                transition={{ duration: 0.2 }}
              >
                {/* Zone Label */}
                <div className="text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {zone}
                </div>

                {/* Content */}
                <div className="space-y-1">
                  {/* Robots */}
                  {robotsByLocation[zone]?.map((robot) => (
                    <motion.div
                      key={robot.id}
                      className={`flex items-center space-x-1 text-xs p-1 rounded cursor-pointer ${
                        selectedRobot === robot.id 
                          ? 'bg-primary-200 dark:bg-primary-800' 
                          : 'hover:bg-white/50 dark:hover:bg-black/50'
                      }`}
                      onClick={() => onRobotClick?.(robot)}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <Bot className={`h-3 w-3 ${getStatusColor(robot.status)}`} />
                      <span className="truncate text-gray-700 dark:text-gray-300">
                        {robot.name.replace(' Bot', '')}
                      </span>
                      <div className="w-2 h-2 rounded-full bg-current opacity-75"></div>
                    </motion.div>
                  ))}

                  {/* Inventory Count */}
                  {inventoryByLocation[zone] && (
                    <div className="flex items-center space-x-1 text-xs text-green-600 dark:text-green-400">
                      <Package className="h-3 w-3" />
                      <span>{inventoryByLocation[zone].length} items</span>
                    </div>
                  )}
                </div>
              </motion.div>
            ))
          )}
        </div>

        {/* Zone Details */}
        {selectedRobot && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-4 bg-primary-50 dark:bg-primary-900/20 border border-primary-200 dark:border-primary-800 rounded-lg"
          >
            {(() => {
              const robot = robots.find(r => r.id === selectedRobot)
              if (!robot) return null
              
              return (
                <div>
                  <h4 className="font-medium text-primary-800 dark:text-primary-300 mb-2">
                    {robot.name} Details
                  </h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600 dark:text-gray-400">Status:</span>
                      <span className="ml-2 text-gray-900 dark:text-gray-100">{robot.status}</span>
                    </div>
                    <div>
                      <span className="text-gray-600 dark:text-gray-400">Battery:</span>
                      <span className="ml-2 text-gray-900 dark:text-gray-100">{robot.batteryLevel}%</span>
                    </div>
                    <div>
                      <span className="text-gray-600 dark:text-gray-400">Location:</span>
                      <span className="ml-2 text-gray-900 dark:text-gray-100">{robot.location}</span>
                    </div>
                    <div>
                      <span className="text-gray-600 dark:text-gray-400">ID:</span>
                      <span className="ml-2 text-gray-900 dark:text-gray-100">{robot.id}</span>
                    </div>
                  </div>
                </div>
              )
            })()}
          </motion.div>
        )}
      </div>
    </Card>
  )
}

export default WarehouseMap