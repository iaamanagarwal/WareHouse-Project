import { describe, it, expect } from 'vitest'
import { renderHook, act } from '@testing-library/react'
import useWarehouseStore from './useWarehouseStore'

describe('useWarehouseStore', () => {
  it('should initialize with default data', () => {
    const { result } = renderHook(() => useWarehouseStore())
    
    expect(result.current.robots.length).toBeGreaterThan(0)
    expect(result.current.tasks.length).toBeGreaterThan(0)
    expect(result.current.inventory.length).toBeGreaterThan(0)
  })

  it('should update robot status correctly', () => {
    const { result } = renderHook(() => useWarehouseStore())
    
    act(() => {
      result.current.updateRobotStatus('ROBOT-001', 'Charging')
    })

    const updatedRobot = result.current.robots.find(robot => robot.id === 'ROBOT-001')
    expect(updatedRobot?.status).toBe('Charging')
  })

  it('should add new task correctly', () => {
    const { result } = renderHook(() => useWarehouseStore())
    const initialTaskCount = result.current.tasks.length

    const newTask = {
      title: 'Move Package A to Zone B',
      description: 'Test task description',
      priority: 'High',
      source: 'A1',
      destination: 'B2',
      itemId: 'ITEM-001'
    }

    act(() => {
      result.current.addTask(newTask)
    })

    expect(result.current.tasks).toHaveLength(initialTaskCount + 1)
    expect(result.current.tasks[result.current.tasks.length - 1].title).toBe('Move Package A to Zone B')
  })

  it('should get available robots correctly', () => {
    const { result } = renderHook(() => useWarehouseStore())
    
    const availableRobots = result.current.getAvailableRobots()
    expect(availableRobots.every(robot => robot.status === 'Idle')).toBe(true)
  })

  it('should get low stock items correctly', () => {
    const { result } = renderHook(() => useWarehouseStore())
    
    const lowStockItems = result.current.getLowStockItems()
    expect(lowStockItems.every(item => item.quantity <= item.minStock)).toBe(true)
  })
})