import { create } from 'zustand'
import { robotsMock } from '../data/robotsMock'
import { tasksMock } from '../data/tasksMock'
import { inventoryMock } from '../data/inventoryMock'

/**
 * Zustand store for warehouse management
 * Manages robots, tasks, and inventory state with actions
 */
const useWarehouseStore = create((set, get) => ({
  // State
  robots: robotsMock,
  tasks: tasksMock,
  inventory: inventoryMock,

  // Robot actions
  updateRobotStatus: (robotId, status) =>
    set((state) => ({
      robots: state.robots.map((robot) =>
        robot.id === robotId ? { ...robot, status } : robot
      ),
    })),

  updateRobotLocation: (robotId, location) =>
    set((state) => ({
      robots: state.robots.map((robot) =>
        robot.id === robotId ? { ...robot, location } : robot
      ),
    })),

  updateRobotBattery: (robotId, batteryLevel) =>
    set((state) => ({
      robots: state.robots.map((robot) =>
        robot.id === robotId ? { ...robot, batteryLevel } : robot
      ),
    })),

  // Task actions
  addTask: (task) =>
    set((state) => ({
      tasks: [
        ...state.tasks,
        {
          ...task,
          id: `TASK-${String(state.tasks.length + 1).padStart(3, '0')}`,
          createdAt: new Date().toISOString(),
          status: 'Pending',
        },
      ],
    })),

  updateTaskStatus: (taskId, status, robotId = null) =>
    set((state) => {
      const updatedTasks = state.tasks.map((task) => {
        if (task.id === taskId) {
          const updatedTask = { ...task, status }
          if (status === 'Completed') {
            updatedTask.completedAt = new Date().toISOString()
          }
          if (robotId !== null) {
            updatedTask.robotId = robotId
          }
          return updatedTask
        }
        return task
      })

      // Update robot status based on task assignment
      const updatedRobots = state.robots.map((robot) => {
        if (robotId && robot.id === robotId) {
          return {
            ...robot,
            status: status === 'Completed' ? 'Idle' : 'Busy',
          }
        }
        return robot
      })

      return {
        tasks: updatedTasks,
        robots: updatedRobots,
      }
    }),

  assignRobotToTask: (taskId, robotId) =>
    set((state) => {
      const updatedTasks = state.tasks.map((task) =>
        task.id === taskId
          ? { ...task, robotId, status: 'In-progress' }
          : task
      )

      const updatedRobots = state.robots.map((robot) =>
        robot.id === robotId ? { ...robot, status: 'Busy' } : robot
      )

      return {
        tasks: updatedTasks,
        robots: updatedRobots,
      }
    }),

  // Inventory actions
  updateInventoryItem: (itemId, updates) =>
    set((state) => ({
      inventory: state.inventory.map((item) =>
        item.id === itemId ? { ...item, ...updates } : item
      ),
    })),

  addInventoryItem: (item) =>
    set((state) => ({
      inventory: [
        ...state.inventory,
        {
          ...item,
          id: `ITEM-${String(state.inventory.length + 1).padStart(3, '0')}`,
        },
      ],
    })),

  // Computed getters
  getAvailableRobots: () => {
    const state = get()
    return state.robots.filter((robot) => robot.status === 'Idle')
  },

  getActiveTasks: () => {
    const state = get()
    return state.tasks.filter(
      (task) => task.status === 'Pending' || task.status === 'In-progress'
    )
  },

  getCompletedTasks: () => {
    const state = get()
    return state.tasks.filter((task) => task.status === 'Completed')
  },

  getLowStockItems: () => {
    const state = get()
    return state.inventory.filter((item) => item.quantity <= item.minStock)
  },

  getRobotStatusCounts: () => {
    const state = get()
    const counts = { Idle: 0, Busy: 0, Charging: 0 }
    state.robots.forEach((robot) => {
      counts[robot.status] = (counts[robot.status] || 0) + 1
    })
    return Object.entries(counts).map(([status, count]) => ({
      status,
      count,
    }))
  },

  getInventoryByCategory: () => {
    const state = get()
    const categoryMap = {}
    state.inventory.forEach((item) => {
      if (!categoryMap[item.category]) {
        categoryMap[item.category] = { category: item.category, quantity: 0, items: 0 }
      }
      categoryMap[item.category].quantity += item.quantity
      categoryMap[item.category].items += 1
    })
    return Object.values(categoryMap)
  },
}))

export default useWarehouseStore