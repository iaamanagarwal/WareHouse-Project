/**
 * Status and color utility functions
 */

/**
 * Get color for robot status
 * @param {string} status - Robot status
 * @returns {Object} Color configuration
 */
export const getRobotStatusColors = (status) => {
  const colors = {
    Idle: {
      bg: 'bg-gray-100 dark:bg-gray-700',
      text: 'text-gray-800 dark:text-gray-300',
      border: 'border-gray-300 dark:border-gray-600',
      dot: 'bg-gray-500'
    },
    Busy: {
      bg: 'bg-amber-100 dark:bg-amber-900',
      text: 'text-amber-800 dark:text-amber-300',
      border: 'border-amber-300 dark:border-amber-600',
      dot: 'bg-amber-500'
    },
    Charging: {
      bg: 'bg-green-100 dark:bg-green-900',
      text: 'text-green-800 dark:text-green-300',
      border: 'border-green-300 dark:border-green-600',
      dot: 'bg-green-500'
    }
  }
  
  return colors[status] || colors.Idle
}

/**
 * Get color for task status
 * @param {string} status - Task status
 * @returns {Object} Color configuration
 */
export const getTaskStatusColors = (status) => {
  const colors = {
    Pending: {
      bg: 'bg-gray-100 dark:bg-gray-700',
      text: 'text-gray-800 dark:text-gray-300',
      border: 'border-gray-300 dark:border-gray-600',
      dot: 'bg-gray-500'
    },
    'In-progress': {
      bg: 'bg-blue-100 dark:bg-blue-900',
      text: 'text-blue-800 dark:text-blue-300',
      border: 'border-blue-300 dark:border-blue-600',
      dot: 'bg-blue-500'
    },
    Completed: {
      bg: 'bg-green-100 dark:bg-green-900',
      text: 'text-green-800 dark:text-green-300',
      border: 'border-green-300 dark:border-green-600',
      dot: 'bg-green-500'
    }
  }
  
  return colors[status] || colors.Pending
}

/**
 * Get color for priority
 * @param {string} priority - Task priority
 * @returns {Object} Color configuration
 */
export const getPriorityColors = (priority) => {
  const colors = {
    Low: {
      bg: 'bg-blue-100 dark:bg-blue-900',
      text: 'text-blue-800 dark:text-blue-300',
      border: 'border-blue-300 dark:border-blue-600',
      dot: 'bg-blue-500'
    },
    Medium: {
      bg: 'bg-yellow-100 dark:bg-yellow-900',
      text: 'text-yellow-800 dark:text-yellow-300',
      border: 'border-yellow-300 dark:border-yellow-600',
      dot: 'bg-yellow-500'
    },
    High: {
      bg: 'bg-red-100 dark:bg-red-900',
      text: 'text-red-800 dark:text-red-300',
      border: 'border-red-300 dark:border-red-600',
      dot: 'bg-red-500'
    }
  }
  
  return colors[priority] || colors.Medium
}

/**
 * Get battery level color
 * @param {number} level - Battery level (0-100)
 * @returns {string} Tailwind color class
 */
export const getBatteryLevelColor = (level) => {
  if (level >= 80) return 'bg-green-500'
  if (level >= 50) return 'bg-yellow-500'
  if (level >= 20) return 'bg-orange-500'
  return 'bg-red-500'
}

/**
 * Get stock level status
 * @param {number} current - Current stock
 * @param {number} minimum - Minimum stock level
 * @returns {Object} Status information
 */
export const getStockStatus = (current, minimum) => {
  const isLow = current <= minimum
  const percentage = minimum > 0 ? (current / minimum) * 100 : 100
  
  return {
    isLow,
    percentage,
    status: isLow ? 'Low Stock' : 'In Stock',
    color: isLow ? 'red' : 'green',
    urgency: percentage < 50 ? 'critical' : percentage < 80 ? 'warning' : 'normal'
  }
}