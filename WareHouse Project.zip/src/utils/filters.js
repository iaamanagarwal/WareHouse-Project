/**
 * Utility functions for filtering and searching data
 */

/**
 * Filter items based on search term
 * @param {Array} items - Array of items to filter
 * @param {string} searchTerm - Search term
 * @param {Array} searchFields - Fields to search in
 * @returns {Array} Filtered items
 */
export const filterBySearch = (items, searchTerm, searchFields) => {
  if (!searchTerm.trim()) return items
  
  const lowerSearchTerm = searchTerm.toLowerCase()
  
  return items.filter(item => 
    searchFields.some(field => {
      const value = getNestedValue(item, field)
      return value && value.toString().toLowerCase().includes(lowerSearchTerm)
    })
  )
}

/**
 * Get nested object value by dot notation
 * @param {Object} obj - Object to search in
 * @param {string} path - Dot notation path (e.g., 'robot.status')
 * @returns {any} Value at path
 */
export const getNestedValue = (obj, path) => {
  return path.split('.').reduce((current, key) => current?.[key], obj)
}

/**
 * Filter items by category
 * @param {Array} items - Array of items to filter
 * @param {string} category - Category to filter by
 * @param {string} categoryField - Field name for category
 * @returns {Array} Filtered items
 */
export const filterByCategory = (items, category, categoryField = 'category') => {
  if (category === 'All' || !category) return items
  return items.filter(item => item[categoryField] === category)
}

/**
 * Filter items by status
 * @param {Array} items - Array of items to filter
 * @param {string} status - Status to filter by
 * @param {string} statusField - Field name for status
 * @returns {Array} Filtered items
 */
export const filterByStatus = (items, status, statusField = 'status') => {
  if (status === 'All' || !status) return items
  return items.filter(item => item[statusField] === status)
}

/**
 * Sort items by field
 * @param {Array} items - Array of items to sort
 * @param {string} field - Field to sort by
 * @param {string} direction - Sort direction ('asc' or 'desc')
 * @returns {Array} Sorted items
 */
export const sortItems = (items, field, direction = 'asc') => {
  return [...items].sort((a, b) => {
    let aVal = getNestedValue(a, field)
    let bVal = getNestedValue(b, field)
    
    // Handle different data types
    if (typeof aVal === 'string') {
      aVal = aVal.toLowerCase()
      bVal = bVal.toLowerCase()
    }
    
    if (direction === 'asc') {
      return aVal < bVal ? -1 : aVal > bVal ? 1 : 0
    } else {
      return aVal > bVal ? -1 : aVal < bVal ? 1 : 0
    }
  })
}