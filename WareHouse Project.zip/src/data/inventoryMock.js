// Mock inventory data
export const inventoryMock = [
  {
    id: 'ITEM-001',
    name: 'Widget A',
    quantity: 150,
    location: 'Zone A1',
    category: 'Components',
    minStock: 50,
    unitCost: 12.50
  },
  {
    id: 'ITEM-002',
    name: 'Screws (M6x20)',
    quantity: 5,
    location: 'Rack B2',
    category: 'Fasteners',
    minStock: 100,
    unitCost: 0.15
  },
  {
    id: 'ITEM-003',
    name: 'Raw Material Steel',
    quantity: 250,
    location: 'Zone D1',
    category: 'Raw Materials',
    minStock: 100,
    unitCost: 8.75
  },
  {
    id: 'ITEM-004',
    name: 'Circuit Board',
    quantity: 75,
    location: 'Aisle 4',
    category: 'Electronics',
    minStock: 25,
    unitCost: 45.00
  },
  {
    id: 'ITEM-005',
    name: 'Gadget B',
    quantity: 200,
    location: 'Zone C3',
    category: 'Components',
    minStock: 75,
    unitCost: 28.90
  },
  {
    id: 'ITEM-006',
    name: 'Bolts (M8x30)',
    quantity: 8,
    location: 'Rack B3',
    category: 'Fasteners',
    minStock: 50,
    unitCost: 0.25
  },
  {
    id: 'ITEM-007',
    name: 'Finished Product X',
    quantity: 120,
    location: 'Zone F1',
    category: 'Finished Goods',
    minStock: 20,
    unitCost: 125.00
  },
  {
    id: 'ITEM-008',
    name: 'Component C',
    quantity: 85,
    location: 'Zone D3',
    category: 'Components',
    minStock: 30,
    unitCost: 18.75
  },
  {
    id: 'ITEM-009',
    name: 'Plastic Housing',
    quantity: 3,
    location: 'Aisle 2',
    category: 'Packaging',
    minStock: 40,
    unitCost: 6.50
  },
  {
    id: 'ITEM-010',
    name: 'Packaging Materials',
    quantity: 500,
    location: 'Zone B3',
    category: 'Packaging',
    minStock: 100,
    unitCost: 2.25
  },
  {
    id: 'ITEM-011',
    name: 'Motor Assembly',
    quantity: 45,
    location: 'Zone E2',
    category: 'Components',
    minStock: 15,
    unitCost: 89.00
  },
  {
    id: 'ITEM-012',
    name: 'Assembly Kit',
    quantity: 95,
    location: 'Zone B1',
    category: 'Kits',
    minStock: 25,
    unitCost: 67.50
  },
  {
    id: 'ITEM-013',
    name: 'Washers (M6)',
    quantity: 2,
    location: 'Rack A1',
    category: 'Fasteners',
    minStock: 200,
    unitCost: 0.05
  },
  {
    id: 'ITEM-014',
    name: 'Power Supply Unit',
    quantity: 30,
    location: 'Zone E1',
    category: 'Electronics',
    minStock: 10,
    unitCost: 156.00
  },
  {
    id: 'ITEM-015',
    name: 'Electronic Parts Kit',
    quantity: 60,
    location: 'Aisle 3',
    category: 'Electronics',
    minStock: 20,
    unitCost: 34.25
  },
  {
    id: 'ITEM-016',
    name: 'Rubber Gaskets',
    quantity: 180,
    location: 'Zone C2',
    category: 'Seals',
    minStock: 50,
    unitCost: 3.75
  },
  {
    id: 'ITEM-017',
    name: 'Bearings (608)',
    quantity: 7,
    location: 'Rack C1',
    category: 'Components',
    minStock: 25,
    unitCost: 12.00
  },
  {
    id: 'ITEM-018',
    name: 'QC Test Samples',
    quantity: 25,
    location: 'QC Lab',
    category: 'Testing',
    minStock: 10,
    unitCost: 5.00
  },
  {
    id: 'ITEM-019',
    name: 'Labels & Stickers',
    quantity: 1000,
    location: 'Zone F2',
    category: 'Packaging',
    minStock: 250,
    unitCost: 0.10
  },
  {
    id: 'ITEM-020',
    name: 'Maintenance Tools',
    quantity: 15,
    location: 'Zone C1',
    category: 'Tools',
    minStock: 5,
    unitCost: 75.00
  }
]