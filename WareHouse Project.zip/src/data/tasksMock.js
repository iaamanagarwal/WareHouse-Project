// Mock tasks data
export const tasksMock = [
  {
    id: 'TASK-001',
    description: 'Move Widget A from Zone A1 to Zone B2',
    robotId: 'ROBOT-001',
    status: 'In-progress',
    itemId: 'ITEM-001',
    source: 'Zone A1',
    destination: 'Zone B2',
    createdAt: '2024-12-02T10:30:00Z',
    priority: 'High'
  },
  {
    id: 'TASK-002',
    description: 'Transport Gadget B to Shipping Dock',
    robotId: 'ROBOT-004',
    status: 'In-progress',
    itemId: 'ITEM-005',
    source: 'Zone C3',
    destination: 'Shipping Dock',
    createdAt: '2024-12-02T09:15:00Z',
    priority: 'Medium'
  },
  {
    id: 'TASK-003',
    description: 'Relocate Component C to Storage Area',
    robotId: 'ROBOT-008',
    status: 'In-progress',
    itemId: 'ITEM-008',
    source: 'Receiving Dock',
    destination: 'Zone D3',
    createdAt: '2024-12-02T11:45:00Z',
    priority: 'Low'
  },
  {
    id: 'TASK-004',
    description: 'Move Assembly Kit to Production Line',
    robotId: 'ROBOT-010',
    status: 'In-progress',
    itemId: 'ITEM-012',
    source: 'Zone B1',
    destination: 'Production Line 2',
    createdAt: '2024-12-02T08:20:00Z',
    priority: 'High'
  },
  {
    id: 'TASK-005',
    description: 'Transport Electronic Parts to Zone A3',
    robotId: null,
    status: 'Pending',
    itemId: 'ITEM-015',
    source: 'Receiving Dock',
    destination: 'Zone A3',
    createdAt: '2024-12-02T12:00:00Z',
    priority: 'Medium'
  },
  {
    id: 'TASK-006',
    description: 'Move Tools to Maintenance Area',
    robotId: null,
    status: 'Pending',
    itemId: 'ITEM-020',
    source: 'Zone C1',
    destination: 'Maintenance Area',
    createdAt: '2024-12-02T13:30:00Z',
    priority: 'Low'
  },
  {
    id: 'TASK-007',
    description: 'Relocate Raw Materials to Production',
    robotId: null,
    status: 'Pending',
    itemId: 'ITEM-003',
    source: 'Zone D1',
    destination: 'Production Line 1',
    createdAt: '2024-12-02T14:00:00Z',
    priority: 'High'
  },
  {
    id: 'TASK-008',
    description: 'Transport Finished Goods to Shipping',
    robotId: 'ROBOT-002',
    status: 'Completed',
    itemId: 'ITEM-007',
    source: 'Production Line 3',
    destination: 'Shipping Dock',
    createdAt: '2024-12-01T16:30:00Z',
    completedAt: '2024-12-01T17:15:00Z',
    priority: 'Medium'
  },
  {
    id: 'TASK-009',
    description: 'Move Packaging Materials to Assembly',
    robotId: 'ROBOT-005',
    status: 'Completed',
    itemId: 'ITEM-010',
    source: 'Zone B3',
    destination: 'Assembly Area',
    createdAt: '2024-12-01T14:20:00Z',
    completedAt: '2024-12-01T15:00:00Z',
    priority: 'Low'
  },
  {
    id: 'TASK-010',
    description: 'Transport Quality Control Samples',
    robotId: 'ROBOT-007',
    status: 'Completed',
    itemId: 'ITEM-018',
    source: 'Production Line 1',
    destination: 'QC Lab',
    createdAt: '2024-12-01T10:45:00Z',
    completedAt: '2024-12-01T11:30:00Z',
    priority: 'High'
  }
]