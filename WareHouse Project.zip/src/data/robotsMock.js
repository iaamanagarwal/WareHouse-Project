// Mock robots data
export const robotsMock = [
  {
    id: 'ROBOT-001',
    status: 'Busy',
    batteryLevel: 85,
    location: 'Zone A3',
    name: 'Alpha Bot'
  },
  {
    id: 'ROBOT-002',
    status: 'Idle',
    batteryLevel: 92,
    location: 'Dock 1',
    name: 'Beta Bot'
  },
  {
    id: 'ROBOT-003',
    status: 'Charging',
    batteryLevel: 45,
    location: 'Charging Station 1',
    name: 'Gamma Bot'
  },
  {
    id: 'ROBOT-004',
    status: 'Busy',
    batteryLevel: 67,
    location: 'Zone B2',
    name: 'Delta Bot'
  },
  {
    id: 'ROBOT-005',
    status: 'Idle',
    batteryLevel: 78,
    location: 'Dock 2',
    name: 'Epsilon Bot'
  },
  {
    id: 'ROBOT-006',
    status: 'Charging',
    batteryLevel: 23,
    location: 'Charging Station 2',
    name: 'Zeta Bot'
  },
  {
    id: 'ROBOT-007',
    status: 'Idle',
    batteryLevel: 89,
    location: 'Zone C1',
    name: 'Eta Bot'
  },
  {
    id: 'ROBOT-008',
    status: 'Busy',
    batteryLevel: 56,
    location: 'Zone A1',
    name: 'Theta Bot'
  },
  {
    id: 'ROBOT-009',
    status: 'Idle',
    batteryLevel: 91,
    location: 'Dock 3',
    name: 'Iota Bot'
  },
  {
    id: 'ROBOT-010',
    status: 'Busy',
    batteryLevel: 73,
    location: 'Zone B3',
    name: 'Kappa Bot'
  },
  {
    id: 'ROBOT-011',
    status: 'Charging',
    batteryLevel: 34,
    location: 'Charging Station 3',
    name: 'Lambda Bot'
  },
  {
    id: 'ROBOT-012',
    status: 'Idle',
    batteryLevel: 95,
    location: 'Zone D1',
    name: 'Mu Bot'
  }
]